-- CherryPick 4.18.0-beta.1 の DB の形。tests/cherrypick/gen-fixture.sh が作る。手で直さない

CREATE TYPE abuse_report_resolver_expiresat_enum AS ENUM (
    '1hour',
    '12hours',
    '1day',
    '1week',
    '1month',
    '3months',
    '6months',
    '1year',
    'indefinitely'
);

CREATE TYPE antenna_src_enum AS ENUM (
    'home',
    'all',
    'users',
    'list',
    'users_blacklist',
    'group'
);

CREATE TYPE event_notevisibility_enum AS ENUM (
    'public',
    'home',
    'followers',
    'specified'
);

CREATE TYPE instance_suspensionstate_enum AS ENUM (
    'none',
    'manuallySuspended',
    'goneSuspended',
    'autoSuspendedForNotResponding'
);

CREATE TYPE log_level_enum AS ENUM (
    'error',
    'warning',
    'info',
    'success',
    'debug'
);

CREATE TYPE meta_sensitivemediadetection_enum AS ENUM (
    'none',
    'all',
    'local',
    'remote'
);

CREATE TYPE meta_sensitivemediadetectionsensitivity_enum AS ENUM (
    'medium',
    'low',
    'high',
    'veryLow',
    'veryHigh'
);

CREATE TYPE muted_note_reason_enum AS ENUM (
    'word',
    'manual',
    'spam',
    'other'
);

CREATE TYPE note_draft_visibility_enum AS ENUM (
    'public',
    'home',
    'followers',
    'specified'
);

CREATE TYPE note_history_visibility_enum AS ENUM (
    'public',
    'home',
    'followers',
    'specified'
);

CREATE TYPE note_visibility_enum AS ENUM (
    'public',
    'home',
    'followers',
    'specified'
);

CREATE TYPE notification_type_enum AS ENUM (
    'follow',
    'mention',
    'reply',
    'renote',
    'quote',
    'reaction',
    'pollVote',
    'pollEnded',
    'receiveFollowRequest',
    'followRequestAccepted',
    'groupInvited',
    'achievementEarned',
    'app'
);

CREATE TYPE page_visibility_enum AS ENUM (
    'public',
    'followers',
    'specified'
);

CREATE TYPE poll_notevisibility_enum AS ENUM (
    'public',
    'home',
    'followers',
    'specified'
);

CREATE TYPE relay_status_enum AS ENUM (
    'requesting',
    'accepted',
    'rejected'
);

CREATE TYPE role_target_enum AS ENUM (
    'manual',
    'conditional'
);

CREATE TYPE user_profile_followersvisibility_enum AS ENUM (
    'public',
    'followers',
    'private'
);

CREATE TYPE user_profile_followingvisibility_enum AS ENUM (
    'public',
    'followers',
    'private'
);

CREATE TYPE user_profile_mutingnotificationtypes_enum AS ENUM (
    'note',
    'follow',
    'mention',
    'reply',
    'renote',
    'quote',
    'reaction',
    'pollEnded',
    'receiveFollowRequest',
    'followRequestAccepted',
    'achievementEarned',
    'app',
    'test',
    'pollVote',
    'groupInvited'
);

CREATE TABLE __chart__active_users (
    id integer NOT NULL,
    date integer NOT NULL,
    "unique_temp___registeredWithinWeek" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredWithinWe_not_null" NOT NULL,
    "___registeredWithinWeek" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredWithinMonth" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredWithinMo_not_null" NOT NULL,
    "___registeredWithinMonth" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredWithinYear" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredWithinYe_not_null" NOT NULL,
    "___registeredWithinYear" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideWeek" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredOutsideW_not_null" NOT NULL,
    "___registeredOutsideWeek" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideMonth" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredOutsideM_not_null" NOT NULL,
    "___registeredOutsideMonth" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideYear" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart__active_users_unique_temp___registeredOutsideY_not_null" NOT NULL,
    "___registeredOutsideYear" integer DEFAULT '0'::smallint NOT NULL,
    "___readWrite" integer DEFAULT '0'::smallint NOT NULL,
    unique_temp___read character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___read integer DEFAULT '0'::smallint NOT NULL,
    unique_temp___write character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___write integer DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart__active_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__active_users_id_seq OWNED BY __chart__active_users.id;

CREATE TABLE __chart__ap_request (
    id integer NOT NULL,
    date integer NOT NULL,
    "___deliverFailed" integer DEFAULT 0 NOT NULL,
    "___deliverSucceeded" integer DEFAULT 0 NOT NULL,
    "___inboxReceived" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart__ap_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__ap_request_id_seq OWNED BY __chart__ap_request.id;

CREATE TABLE __chart__drive (
    id integer NOT NULL,
    date integer NOT NULL,
    "___local_incCount" integer DEFAULT '0'::bigint NOT NULL,
    "___local_incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___local_decCount" integer DEFAULT '0'::bigint NOT NULL,
    "___local_decSize" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_incCount" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_decCount" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_decSize" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__drive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__drive_id_seq OWNED BY __chart__drive.id;

CREATE TABLE __chart__federation (
    id integer NOT NULL,
    date integer NOT NULL,
    "unique_temp___deliveredInstances" character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    "___deliveredInstances" smallint DEFAULT '0'::smallint NOT NULL,
    "unique_temp___inboxInstances" character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    "___inboxInstances" smallint DEFAULT '0'::smallint NOT NULL,
    unique_temp___stalled character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___stalled smallint DEFAULT '0'::smallint NOT NULL,
    ___sub smallint DEFAULT '0'::smallint NOT NULL,
    ___pub smallint DEFAULT '0'::smallint NOT NULL,
    ___pubsub smallint DEFAULT '0'::smallint NOT NULL,
    "___subActive" smallint DEFAULT '0'::smallint NOT NULL,
    "___pubActive" smallint DEFAULT '0'::smallint NOT NULL,
    ___software smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart__federation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__federation_id_seq OWNED BY __chart__federation.id;

CREATE TABLE __chart__hashtag (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_users integer DEFAULT 0 NOT NULL,
    ___remote_users integer DEFAULT 0 NOT NULL,
    unique_temp___local_users character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    unique_temp___remote_users character varying[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE SEQUENCE __chart__hashtag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__hashtag_id_seq OWNED BY __chart__hashtag.id;

CREATE TABLE __chart__instance (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___requests_failed smallint DEFAULT '0'::bigint NOT NULL,
    ___requests_succeeded smallint DEFAULT '0'::bigint NOT NULL,
    ___requests_received smallint DEFAULT '0'::bigint NOT NULL,
    ___notes_total integer DEFAULT '0'::bigint NOT NULL,
    ___notes_inc integer DEFAULT '0'::bigint NOT NULL,
    ___notes_dec integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    ___users_total integer DEFAULT '0'::bigint NOT NULL,
    ___users_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___users_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___following_total integer DEFAULT '0'::bigint NOT NULL,
    ___following_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___following_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___followers_total integer DEFAULT '0'::bigint NOT NULL,
    ___followers_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___followers_dec smallint DEFAULT '0'::bigint NOT NULL,
    "___drive_totalFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_incFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_incUsage" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_decFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_decUsage" integer DEFAULT '0'::bigint NOT NULL,
    "___notes_diffs_withFile" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart__instance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__instance_id_seq OWNED BY __chart__instance.id;

CREATE TABLE __chart__network (
    id integer NOT NULL,
    date integer NOT NULL,
    "___incomingRequests" integer DEFAULT '0'::bigint NOT NULL,
    "___outgoingRequests" integer DEFAULT '0'::bigint NOT NULL,
    "___totalTime" integer DEFAULT '0'::bigint NOT NULL,
    "___incomingBytes" integer DEFAULT '0'::bigint NOT NULL,
    "___outgoingBytes" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__network_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__network_id_seq OWNED BY __chart__network.id;

CREATE TABLE __chart__notes (
    id integer NOT NULL,
    date integer NOT NULL,
    ___local_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_inc integer DEFAULT '0'::bigint NOT NULL,
    ___local_dec integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    ___remote_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_inc integer DEFAULT '0'::bigint NOT NULL,
    ___remote_dec integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    "___local_diffs_withFile" integer DEFAULT 0 NOT NULL,
    "___remote_diffs_withFile" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart__notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__notes_id_seq OWNED BY __chart__notes.id;

CREATE TABLE __chart__per_user_drive (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    "___totalCount" integer DEFAULT '0'::bigint NOT NULL,
    "___totalSize" integer DEFAULT '0'::bigint NOT NULL,
    "___incCount" smallint DEFAULT '0'::bigint NOT NULL,
    "___incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___decCount" smallint DEFAULT '0'::bigint NOT NULL,
    "___decSize" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__per_user_drive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__per_user_drive_id_seq OWNED BY __chart__per_user_drive.id;

CREATE TABLE __chart__per_user_following (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_followings_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_followings_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___local_followings_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___local_followers_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_followers_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___local_followers_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_followings_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_followings_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_followings_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_followers_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_followers_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_followers_dec smallint DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__per_user_following_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__per_user_following_id_seq OWNED BY __chart__per_user_following.id;

CREATE TABLE __chart__per_user_notes (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___total integer DEFAULT '0'::bigint NOT NULL,
    ___inc smallint DEFAULT '0'::bigint NOT NULL,
    ___dec smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_normal smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_reply smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_renote smallint DEFAULT '0'::bigint NOT NULL,
    "___diffs_withFile" smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart__per_user_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__per_user_notes_id_seq OWNED BY __chart__per_user_notes.id;

CREATE TABLE __chart__per_user_pv (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    unique_temp___upv_user character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___upv_user smallint DEFAULT '0'::smallint NOT NULL,
    ___pv_user smallint DEFAULT '0'::smallint NOT NULL,
    unique_temp___upv_visitor character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___upv_visitor smallint DEFAULT '0'::smallint NOT NULL,
    ___pv_visitor smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart__per_user_pv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__per_user_pv_id_seq OWNED BY __chart__per_user_pv.id;

CREATE TABLE __chart__per_user_reaction (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_count smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_count smallint DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__per_user_reaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__per_user_reaction_id_seq OWNED BY __chart__per_user_reaction.id;

CREATE TABLE __chart__test (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128),
    ___foo_total bigint NOT NULL,
    ___foo_inc bigint NOT NULL,
    ___foo_dec bigint NOT NULL
);

CREATE TABLE __chart__test_grouped (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128),
    ___foo_total bigint NOT NULL,
    ___foo_inc bigint NOT NULL,
    ___foo_dec bigint NOT NULL
);

CREATE SEQUENCE __chart__test_grouped_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__test_grouped_id_seq OWNED BY __chart__test_grouped.id;

CREATE SEQUENCE __chart__test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__test_id_seq OWNED BY __chart__test.id;

CREATE TABLE __chart__test_unique (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128),
    ___foo character varying[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE SEQUENCE __chart__test_unique_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__test_unique_id_seq OWNED BY __chart__test_unique.id;

CREATE TABLE __chart__users (
    id integer NOT NULL,
    date integer NOT NULL,
    ___local_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___local_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_dec smallint DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart__users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart__users_id_seq OWNED BY __chart__users.id;

CREATE TABLE __chart_day__active_users (
    id integer NOT NULL,
    date integer NOT NULL,
    "unique_temp___registeredWithinWeek" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredWith_not_null" NOT NULL,
    "___registeredWithinWeek" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredWithinMonth" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredWit_not_null1" NOT NULL,
    "___registeredWithinMonth" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredWithinYear" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredWit_not_null2" NOT NULL,
    "___registeredWithinYear" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideWeek" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredOuts_not_null" NOT NULL,
    "___registeredOutsideWeek" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideMonth" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredOut_not_null1" NOT NULL,
    "___registeredOutsideMonth" integer DEFAULT '0'::smallint NOT NULL,
    "unique_temp___registeredOutsideYear" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__active_users_unique_temp___registeredOut_not_null2" NOT NULL,
    "___registeredOutsideYear" integer DEFAULT '0'::smallint NOT NULL,
    "___readWrite" integer DEFAULT '0'::smallint NOT NULL,
    unique_temp___read character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___read integer DEFAULT '0'::smallint NOT NULL,
    unique_temp___write character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___write integer DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart_day__active_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__active_users_id_seq OWNED BY __chart_day__active_users.id;

CREATE TABLE __chart_day__ap_request (
    id integer NOT NULL,
    date integer NOT NULL,
    "___deliverFailed" integer DEFAULT 0 NOT NULL,
    "___deliverSucceeded" integer DEFAULT 0 NOT NULL,
    "___inboxReceived" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart_day__ap_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__ap_request_id_seq OWNED BY __chart_day__ap_request.id;

CREATE TABLE __chart_day__drive (
    id integer NOT NULL,
    date integer NOT NULL,
    "___local_incCount" integer DEFAULT '0'::bigint NOT NULL,
    "___local_incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___local_decCount" integer DEFAULT '0'::bigint NOT NULL,
    "___local_decSize" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_incCount" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_decCount" integer DEFAULT '0'::bigint NOT NULL,
    "___remote_decSize" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart_day__drive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__drive_id_seq OWNED BY __chart_day__drive.id;

CREATE TABLE __chart_day__federation (
    id integer NOT NULL,
    date integer NOT NULL,
    "unique_temp___deliveredInstances" character varying[] DEFAULT '{}'::character varying[] CONSTRAINT "__chart_day__federation_unique_temp___deliveredInstanc_not_null" NOT NULL,
    "___deliveredInstances" smallint DEFAULT '0'::smallint NOT NULL,
    "unique_temp___inboxInstances" character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    "___inboxInstances" smallint DEFAULT '0'::smallint NOT NULL,
    unique_temp___stalled character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___stalled smallint DEFAULT '0'::smallint NOT NULL,
    ___sub smallint DEFAULT '0'::smallint NOT NULL,
    ___pub smallint DEFAULT '0'::smallint NOT NULL,
    ___pubsub smallint DEFAULT '0'::smallint NOT NULL,
    "___subActive" smallint DEFAULT '0'::smallint NOT NULL,
    "___pubActive" smallint DEFAULT '0'::smallint NOT NULL,
    ___software smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart_day__federation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__federation_id_seq OWNED BY __chart_day__federation.id;

CREATE TABLE __chart_day__hashtag (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_users integer DEFAULT 0 NOT NULL,
    ___remote_users integer DEFAULT 0 NOT NULL,
    unique_temp___local_users character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    unique_temp___remote_users character varying[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE SEQUENCE __chart_day__hashtag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__hashtag_id_seq OWNED BY __chart_day__hashtag.id;

CREATE TABLE __chart_day__instance (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___requests_failed smallint DEFAULT '0'::bigint NOT NULL,
    ___requests_succeeded smallint DEFAULT '0'::bigint NOT NULL,
    ___requests_received smallint DEFAULT '0'::bigint NOT NULL,
    ___notes_total integer DEFAULT '0'::bigint NOT NULL,
    ___notes_inc integer DEFAULT '0'::bigint NOT NULL,
    ___notes_dec integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___notes_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    ___users_total integer DEFAULT '0'::bigint NOT NULL,
    ___users_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___users_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___following_total integer DEFAULT '0'::bigint NOT NULL,
    ___following_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___following_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___followers_total integer DEFAULT '0'::bigint NOT NULL,
    ___followers_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___followers_dec smallint DEFAULT '0'::bigint NOT NULL,
    "___drive_totalFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_incFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_incUsage" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_decFiles" integer DEFAULT '0'::bigint NOT NULL,
    "___drive_decUsage" integer DEFAULT '0'::bigint NOT NULL,
    "___notes_diffs_withFile" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart_day__instance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__instance_id_seq OWNED BY __chart_day__instance.id;

CREATE TABLE __chart_day__network (
    id integer NOT NULL,
    date integer NOT NULL,
    "___incomingRequests" integer DEFAULT '0'::bigint NOT NULL,
    "___outgoingRequests" integer DEFAULT '0'::bigint NOT NULL,
    "___totalTime" integer DEFAULT '0'::bigint NOT NULL,
    "___incomingBytes" integer DEFAULT '0'::bigint NOT NULL,
    "___outgoingBytes" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart_day__network_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__network_id_seq OWNED BY __chart_day__network.id;

CREATE TABLE __chart_day__notes (
    id integer NOT NULL,
    date integer NOT NULL,
    ___local_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_inc integer DEFAULT '0'::bigint NOT NULL,
    ___local_dec integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___local_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    ___remote_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_inc integer DEFAULT '0'::bigint NOT NULL,
    ___remote_dec integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_normal integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_reply integer DEFAULT '0'::bigint NOT NULL,
    ___remote_diffs_renote integer DEFAULT '0'::bigint NOT NULL,
    "___local_diffs_withFile" integer DEFAULT 0 NOT NULL,
    "___remote_diffs_withFile" integer DEFAULT 0 NOT NULL
);

CREATE SEQUENCE __chart_day__notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__notes_id_seq OWNED BY __chart_day__notes.id;

CREATE TABLE __chart_day__per_user_drive (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    "___totalCount" integer DEFAULT '0'::bigint NOT NULL,
    "___totalSize" integer DEFAULT '0'::bigint NOT NULL,
    "___incCount" smallint DEFAULT '0'::bigint NOT NULL,
    "___incSize" integer DEFAULT '0'::bigint NOT NULL,
    "___decCount" smallint DEFAULT '0'::bigint NOT NULL,
    "___decSize" integer DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart_day__per_user_drive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__per_user_drive_id_seq OWNED BY __chart_day__per_user_drive.id;

CREATE TABLE __chart_day__per_user_following (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_followings_total integer DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_follow____local_followings_total_not_null NOT NULL,
    ___local_followings_inc smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followin____local_followings_inc_not_null NOT NULL,
    ___local_followings_dec smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followin____local_followings_dec_not_null NOT NULL,
    ___local_followers_total integer DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followi____local_followers_total_not_null NOT NULL,
    ___local_followers_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___local_followers_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_followings_total integer DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_follo____remote_followings_total_not_null NOT NULL,
    ___remote_followings_inc smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followi____remote_followings_inc_not_null NOT NULL,
    ___remote_followings_dec smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followi____remote_followings_dec_not_null NOT NULL,
    ___remote_followers_total integer DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_follow____remote_followers_total_not_null NOT NULL,
    ___remote_followers_inc smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followin____remote_followers_inc_not_null NOT NULL,
    ___remote_followers_dec smallint DEFAULT '0'::bigint CONSTRAINT __chart_day__per_user_followin____remote_followers_dec_not_null NOT NULL
);

CREATE SEQUENCE __chart_day__per_user_following_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__per_user_following_id_seq OWNED BY __chart_day__per_user_following.id;

CREATE TABLE __chart_day__per_user_notes (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___total integer DEFAULT '0'::bigint NOT NULL,
    ___inc smallint DEFAULT '0'::bigint NOT NULL,
    ___dec smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_normal smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_reply smallint DEFAULT '0'::bigint NOT NULL,
    ___diffs_renote smallint DEFAULT '0'::bigint NOT NULL,
    "___diffs_withFile" smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart_day__per_user_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__per_user_notes_id_seq OWNED BY __chart_day__per_user_notes.id;

CREATE TABLE __chart_day__per_user_pv (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    unique_temp___upv_user character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___upv_user smallint DEFAULT '0'::smallint NOT NULL,
    ___pv_user smallint DEFAULT '0'::smallint NOT NULL,
    unique_temp___upv_visitor character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    ___upv_visitor smallint DEFAULT '0'::smallint NOT NULL,
    ___pv_visitor smallint DEFAULT '0'::smallint NOT NULL
);

CREATE SEQUENCE __chart_day__per_user_pv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__per_user_pv_id_seq OWNED BY __chart_day__per_user_pv.id;

CREATE TABLE __chart_day__per_user_reaction (
    id integer NOT NULL,
    date integer NOT NULL,
    "group" character varying(128) NOT NULL,
    ___local_count smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_count smallint DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart_day__per_user_reaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__per_user_reaction_id_seq OWNED BY __chart_day__per_user_reaction.id;

CREATE TABLE __chart_day__users (
    id integer NOT NULL,
    date integer NOT NULL,
    ___local_total integer DEFAULT '0'::bigint NOT NULL,
    ___local_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___local_dec smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_total integer DEFAULT '0'::bigint NOT NULL,
    ___remote_inc smallint DEFAULT '0'::bigint NOT NULL,
    ___remote_dec smallint DEFAULT '0'::bigint NOT NULL
);

CREATE SEQUENCE __chart_day__users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE __chart_day__users_id_seq OWNED BY __chart_day__users.id;

CREATE TABLE abuse_report_notification_recipient (
    id character varying(32) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    method character varying(64) NOT NULL,
    "userId" character varying(32),
    "systemWebhookId" character varying(32)
);

CREATE TABLE abuse_report_resolver (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(256) NOT NULL,
    "targetUserPattern" character varying(1024),
    "reporterPattern" character varying(1024),
    "reportContentPattern" character varying(1024),
    "expirationDate" timestamp with time zone,
    "expiresAt" abuse_report_resolver_expiresat_enum NOT NULL,
    forward boolean NOT NULL
);

COMMENT ON COLUMN abuse_report_resolver."updatedAt" IS 'The updated date of AbuseReportResolver';

COMMENT ON COLUMN abuse_report_resolver."expirationDate" IS 'The expiration date of AbuseReportResolver';

CREATE TABLE abuse_user_report (
    id character varying(32) NOT NULL,
    "targetUserId" character varying(32) CONSTRAINT "abuse_user_report_userId_not_null" NOT NULL,
    "reporterId" character varying(32) NOT NULL,
    "assigneeId" character varying(32),
    resolved boolean DEFAULT false NOT NULL,
    comment character varying(2048) NOT NULL,
    "targetUserHost" character varying(128),
    "reporterHost" character varying(128),
    forwarded boolean DEFAULT false NOT NULL,
    "moderationNote" character varying(8192) DEFAULT ''::character varying NOT NULL,
    "resolvedAs" character varying(128)
);

COMMENT ON COLUMN abuse_user_report."targetUserHost" IS '[Denormalized]';

COMMENT ON COLUMN abuse_user_report."reporterHost" IS '[Denormalized]';

CREATE TABLE access_token (
    id character varying(32) NOT NULL,
    token character varying(128) NOT NULL,
    hash character varying(128) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "appId" character varying(32),
    "lastUsedAt" timestamp with time zone,
    session character varying(128),
    name character varying(128),
    description character varying(512),
    "iconUrl" character varying(512),
    permission character varying(64)[] DEFAULT '{}'::character varying[] NOT NULL,
    fetched boolean DEFAULT false NOT NULL
);

CREATE TABLE ad (
    id character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    place character varying(32) NOT NULL,
    priority character varying(32) NOT NULL,
    url character varying(1024) NOT NULL,
    "imageUrl" character varying(1024) NOT NULL,
    memo character varying(8192) NOT NULL,
    ratio integer DEFAULT 1 NOT NULL,
    "startsAt" timestamp with time zone DEFAULT now() NOT NULL,
    "dayOfWeek" integer DEFAULT 0 NOT NULL,
    "isSensitive" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN ad."expiresAt" IS 'The expired date of the Ad.';

COMMENT ON COLUMN ad."startsAt" IS 'The expired date of the Ad.';

CREATE TABLE announcement (
    id character varying(32) NOT NULL,
    text character varying(8192) NOT NULL,
    title character varying(256) NOT NULL,
    "imageUrl" character varying(1024),
    "updatedAt" timestamp with time zone,
    display character varying(256) DEFAULT 'normal'::character varying NOT NULL,
    "needConfirmationToRead" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "forExistingUsers" boolean DEFAULT false NOT NULL,
    "userId" character varying(32),
    icon character varying(256) DEFAULT 'info'::character varying NOT NULL,
    silence boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN announcement."updatedAt" IS 'The updated date of the Announcement.';

CREATE TABLE announcement_read (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "announcementId" character varying(32) NOT NULL
);

CREATE TABLE antenna (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    src antenna_src_enum NOT NULL,
    "userListId" character varying(32),
    keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    "withFile" boolean NOT NULL,
    expression character varying(2048),
    "caseSensitive" boolean DEFAULT false NOT NULL,
    "withReplies" boolean DEFAULT false NOT NULL,
    "userGroupJoiningId" character varying(32),
    users character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "excludeKeywords" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "lastUsedAt" timestamp with time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "localOnly" boolean DEFAULT false NOT NULL,
    "excludeBots" boolean DEFAULT false NOT NULL,
    "excludeNotesInSensitiveChannel" boolean DEFAULT false CONSTRAINT "antenna_hideNotesInSensitiveChannel_not_null" NOT NULL
);

COMMENT ON COLUMN antenna."userId" IS 'The owner ID.';

COMMENT ON COLUMN antenna.name IS 'The name of the Antenna.';

CREATE TABLE app (
    id character varying(32) NOT NULL,
    "userId" character varying(32),
    secret character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(512) NOT NULL,
    permission character varying(64)[] NOT NULL,
    "callbackUrl" character varying(512)
);

COMMENT ON COLUMN app."userId" IS 'The owner ID.';

COMMENT ON COLUMN app.secret IS 'The secret key of the App.';

COMMENT ON COLUMN app.name IS 'The name of the App.';

COMMENT ON COLUMN app.description IS 'The description of the App.';

COMMENT ON COLUMN app.permission IS 'The permission of the App.';

COMMENT ON COLUMN app."callbackUrl" IS 'The callbackUrl of the App.';

CREATE TABLE auth_session (
    id character varying(32) NOT NULL,
    token character varying(128) NOT NULL,
    "userId" character varying(32),
    "appId" character varying(32) NOT NULL
);

CREATE TABLE avatar_decoration (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone,
    url character varying(1024) NOT NULL,
    name character varying(256) NOT NULL,
    description character varying(2048) NOT NULL,
    "roleIdsThatCanBeUsedThisDecoration" character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    "remoteId" character varying(32),
    host character varying(128),
    "rawUrl" text
);

CREATE TABLE blocking (
    id character varying(32) NOT NULL,
    "blockeeId" character varying(32) NOT NULL,
    "blockerId" character varying(32) NOT NULL
);

COMMENT ON COLUMN blocking."blockeeId" IS 'The blockee user ID.';

COMMENT ON COLUMN blocking."blockerId" IS 'The blocker user ID.';

CREATE TABLE bubble_game_record (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "seededAt" timestamp with time zone NOT NULL,
    seed character varying(1024) NOT NULL,
    "gameVersion" integer NOT NULL,
    "gameMode" character varying(128) NOT NULL,
    score integer NOT NULL,
    logs jsonb DEFAULT '[]'::jsonb NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL
);

CREATE TABLE channel (
    id character varying(32) NOT NULL,
    "lastNotedAt" timestamp with time zone,
    "userId" character varying(32),
    name character varying(128) NOT NULL,
    description character varying(2048),
    "bannerId" character varying(32),
    "notesCount" integer DEFAULT 0 NOT NULL,
    "usersCount" integer DEFAULT 0 NOT NULL,
    "pinnedNoteIds" character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    color character varying(16) DEFAULT '#86b300'::character varying NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "isSensitive" boolean DEFAULT false NOT NULL,
    "allowRenoteToExternal" boolean DEFAULT true NOT NULL
);

COMMENT ON COLUMN channel."userId" IS 'The owner ID.';

COMMENT ON COLUMN channel.name IS 'The name of the Channel.';

COMMENT ON COLUMN channel.description IS 'The description of the Channel.';

COMMENT ON COLUMN channel."bannerId" IS 'The ID of banner Channel.';

COMMENT ON COLUMN channel."notesCount" IS 'The count of notes.';

COMMENT ON COLUMN channel."usersCount" IS 'The count of users.';

CREATE TABLE channel_favorite (
    id character varying(32) NOT NULL,
    "channelId" character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL
);

CREATE TABLE channel_following (
    id character varying(32) NOT NULL,
    "followeeId" character varying(32) NOT NULL,
    "followerId" character varying(32) NOT NULL
);

COMMENT ON COLUMN channel_following."followeeId" IS 'The followee channel ID.';

COMMENT ON COLUMN channel_following."followerId" IS 'The follower user ID.';

CREATE TABLE channel_muting (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "channelId" character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone
);

CREATE TABLE channel_note_pining (
    id character varying(32) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "channelId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL
);

COMMENT ON COLUMN channel_note_pining."createdAt" IS 'The created date of the ChannelNotePining.';

CREATE TABLE chat_approval (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "otherId" character varying(32) NOT NULL
);

CREATE TABLE chat_message (
    id character varying(32) NOT NULL,
    "fromUserId" character varying(32) NOT NULL,
    "toUserId" character varying(32),
    "toRoomId" character varying(32),
    text character varying(4096),
    uri character varying(512),
    reads character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "fileId" character varying(32),
    reactions character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    emojis character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE TABLE chat_room (
    id character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    "ownerId" character varying(32) NOT NULL,
    description character varying(2048) DEFAULT ''::character varying NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL
);

CREATE TABLE chat_room_invitation (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "roomId" character varying(32) NOT NULL,
    ignored boolean DEFAULT false NOT NULL
);

CREATE TABLE chat_room_membership (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "roomId" character varying(32) NOT NULL,
    "isMuted" boolean DEFAULT false NOT NULL
);

CREATE TABLE clip (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    description character varying(2048),
    "lastClippedAt" timestamp with time zone
);

COMMENT ON COLUMN clip."userId" IS 'The owner ID.';

COMMENT ON COLUMN clip.name IS 'The name of the Clip.';

COMMENT ON COLUMN clip.description IS 'The description of the Clip.';

CREATE TABLE clip_favorite (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "clipId" character varying(32) NOT NULL
);

CREATE TABLE clip_note (
    id character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    "clipId" character varying(32) NOT NULL
);

COMMENT ON COLUMN clip_note."noteId" IS 'The note ID.';

COMMENT ON COLUMN clip_note."clipId" IS 'The clip ID.';

CREATE TABLE drive_file (
    id character varying(32) NOT NULL,
    "userId" character varying(32),
    "userHost" character varying(128),
    md5 character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    type character varying(128) NOT NULL,
    size integer NOT NULL,
    comment character varying(512),
    properties jsonb DEFAULT '{}'::jsonb NOT NULL,
    "storedInternal" boolean NOT NULL,
    url character varying(1024) NOT NULL,
    "thumbnailUrl" character varying(512),
    "webpublicUrl" character varying(512),
    "accessKey" character varying(256),
    "thumbnailAccessKey" character varying(256),
    "webpublicAccessKey" character varying(256),
    uri character varying(1024),
    src character varying(1024),
    "folderId" character varying(32),
    "isSensitive" boolean DEFAULT false NOT NULL,
    "isLink" boolean DEFAULT false NOT NULL,
    blurhash character varying(128),
    "webpublicType" character varying(128),
    "requestHeaders" jsonb DEFAULT '{}'::jsonb,
    "requestIp" character varying(128),
    "maybeSensitive" boolean DEFAULT false NOT NULL,
    "maybePorn" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN drive_file."userId" IS 'The owner ID.';

COMMENT ON COLUMN drive_file."userHost" IS 'The host of owner. It will be null if the user in local.';

COMMENT ON COLUMN drive_file.md5 IS 'The MD5 hash of the DriveFile.';

COMMENT ON COLUMN drive_file.name IS 'The file name of the DriveFile.';

COMMENT ON COLUMN drive_file.type IS 'The content type (MIME) of the DriveFile.';

COMMENT ON COLUMN drive_file.size IS 'The file size (bytes) of the DriveFile.';

COMMENT ON COLUMN drive_file.comment IS 'The comment of the DriveFile.';

COMMENT ON COLUMN drive_file.properties IS 'The any properties of the DriveFile. For example, it includes image width/height.';

COMMENT ON COLUMN drive_file.url IS 'The URL of the DriveFile.';

COMMENT ON COLUMN drive_file."thumbnailUrl" IS 'The URL of the thumbnail of the DriveFile.';

COMMENT ON COLUMN drive_file."webpublicUrl" IS 'The URL of the webpublic of the DriveFile.';

COMMENT ON COLUMN drive_file.uri IS 'The URI of the DriveFile. it will be null when the DriveFile is local.';

COMMENT ON COLUMN drive_file."folderId" IS 'The parent folder ID. If null, it means the DriveFile is located in root.';

COMMENT ON COLUMN drive_file."isSensitive" IS 'Whether the DriveFile is NSFW.';

COMMENT ON COLUMN drive_file."isLink" IS 'Whether the DriveFile is direct link to remote server.';

COMMENT ON COLUMN drive_file.blurhash IS 'The BlurHash string.';

COMMENT ON COLUMN drive_file."maybeSensitive" IS 'Whether the DriveFile is NSFW. (predict)';

CREATE TABLE drive_folder (
    id character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    "userId" character varying(32),
    "parentId" character varying(32)
);

COMMENT ON COLUMN drive_folder.name IS 'The name of the DriveFolder.';

COMMENT ON COLUMN drive_folder."userId" IS 'The owner ID.';

COMMENT ON COLUMN drive_folder."parentId" IS 'The parent folder ID. If null, it means the DriveFolder is located in root.';

CREATE TABLE emoji (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone,
    name character varying(128) NOT NULL,
    host character varying(128),
    "originalUrl" character varying(512) CONSTRAINT emoji_url_not_null NOT NULL,
    uri character varying(512),
    type character varying(64),
    aliases character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    category character varying(128),
    "publicUrl" character varying(512) DEFAULT ''::character varying NOT NULL,
    license character varying(1024),
    "localOnly" boolean DEFAULT false NOT NULL,
    "isSensitive" boolean DEFAULT false NOT NULL,
    "roleIdsThatCanBeUsedThisEmojiAsReaction" character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE TABLE event (
    "noteId" character varying(32) CONSTRAINT event_id_not_null NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone,
    title character varying(128) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    "noteVisibility" event_notevisibility_enum NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userHost" character varying(128)
);

COMMENT ON COLUMN event.start IS 'The start time of the event';

COMMENT ON COLUMN event."end" IS 'The end of the event';

COMMENT ON COLUMN event.title IS 'short name of event';

COMMENT ON COLUMN event.metadata IS 'metadata mapping for event with more user configurable optional information';

COMMENT ON COLUMN event."noteVisibility" IS '[Denormalized]';

COMMENT ON COLUMN event."userId" IS '[Denormalized]';

COMMENT ON COLUMN event."userHost" IS '[Denormalized]';

CREATE TABLE flash (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(256) NOT NULL,
    summary character varying(1024) NOT NULL,
    "userId" character varying(32) NOT NULL,
    script character varying(65536) NOT NULL,
    permissions character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    "likedCount" integer DEFAULT 0 NOT NULL,
    visibility character varying(512) DEFAULT 'public'::character varying NOT NULL
);

COMMENT ON COLUMN flash."updatedAt" IS 'The updated date of the Flash.';

COMMENT ON COLUMN flash."userId" IS 'The ID of author.';

CREATE TABLE flash_like (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "flashId" character varying(32) NOT NULL
);

CREATE TABLE follow_request (
    id character varying(32) NOT NULL,
    "followeeId" character varying(32) NOT NULL,
    "followerId" character varying(32) NOT NULL,
    "requestId" character varying(128),
    "followerHost" character varying(128),
    "followerInbox" character varying(512),
    "followerSharedInbox" character varying(512),
    "followeeHost" character varying(128),
    "followeeInbox" character varying(512),
    "followeeSharedInbox" character varying(512),
    "withReplies" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN follow_request."followeeId" IS 'The followee user ID.';

COMMENT ON COLUMN follow_request."followerId" IS 'The follower user ID.';

COMMENT ON COLUMN follow_request."requestId" IS 'id of Follow Activity.';

COMMENT ON COLUMN follow_request."followerHost" IS '[Denormalized]';

COMMENT ON COLUMN follow_request."followerInbox" IS '[Denormalized]';

COMMENT ON COLUMN follow_request."followerSharedInbox" IS '[Denormalized]';

COMMENT ON COLUMN follow_request."followeeHost" IS '[Denormalized]';

COMMENT ON COLUMN follow_request."followeeInbox" IS '[Denormalized]';

COMMENT ON COLUMN follow_request."followeeSharedInbox" IS '[Denormalized]';

CREATE TABLE following (
    id character varying(32) NOT NULL,
    "followeeId" character varying(32) NOT NULL,
    "followerId" character varying(32) NOT NULL,
    "followerHost" character varying(128),
    "followerInbox" character varying(512),
    "followerSharedInbox" character varying(512),
    "followeeHost" character varying(128),
    "followeeInbox" character varying(512),
    "followeeSharedInbox" character varying(512),
    notify character varying(32),
    "withReplies" boolean DEFAULT false NOT NULL,
    "isFollowerHibernated" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN following."followeeId" IS 'The followee user ID.';

COMMENT ON COLUMN following."followerId" IS 'The follower user ID.';

COMMENT ON COLUMN following."followerHost" IS '[Denormalized]';

COMMENT ON COLUMN following."followerInbox" IS '[Denormalized]';

COMMENT ON COLUMN following."followerSharedInbox" IS '[Denormalized]';

COMMENT ON COLUMN following."followeeHost" IS '[Denormalized]';

COMMENT ON COLUMN following."followeeInbox" IS '[Denormalized]';

COMMENT ON COLUMN following."followeeSharedInbox" IS '[Denormalized]';

CREATE TABLE gallery_like (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "postId" character varying(32) NOT NULL
);

CREATE TABLE gallery_post (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(256) NOT NULL,
    description character varying(2048),
    "userId" character varying(32) NOT NULL,
    "fileIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "isSensitive" boolean DEFAULT false NOT NULL,
    "likedCount" integer DEFAULT 0 NOT NULL,
    tags character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL
);

COMMENT ON COLUMN gallery_post."updatedAt" IS 'The updated date of the GalleryPost.';

COMMENT ON COLUMN gallery_post."userId" IS 'The ID of author.';

COMMENT ON COLUMN gallery_post."isSensitive" IS 'Whether the post is sensitive.';

CREATE TABLE hashtag (
    id character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    "mentionedUserIds" character varying(32)[] NOT NULL,
    "mentionedUsersCount" integer DEFAULT 0 NOT NULL,
    "mentionedLocalUserIds" character varying(32)[] NOT NULL,
    "mentionedLocalUsersCount" integer DEFAULT 0 NOT NULL,
    "mentionedRemoteUserIds" character varying(32)[] NOT NULL,
    "mentionedRemoteUsersCount" integer DEFAULT 0 NOT NULL,
    "attachedUserIds" character varying(32)[] NOT NULL,
    "attachedUsersCount" integer DEFAULT 0 NOT NULL,
    "attachedLocalUserIds" character varying(32)[] NOT NULL,
    "attachedLocalUsersCount" integer DEFAULT 0 NOT NULL,
    "attachedRemoteUserIds" character varying(32)[] NOT NULL,
    "attachedRemoteUsersCount" integer DEFAULT 0 NOT NULL
);

CREATE TABLE instance (
    id character varying(32) NOT NULL,
    "firstRetrievedAt" timestamp with time zone CONSTRAINT "instance_caughtAt_not_null" NOT NULL,
    host character varying(128) NOT NULL,
    "usersCount" integer DEFAULT 0 NOT NULL,
    "notesCount" integer DEFAULT 0 NOT NULL,
    "followingCount" integer DEFAULT 0 NOT NULL,
    "followersCount" integer DEFAULT 0 NOT NULL,
    "latestRequestReceivedAt" timestamp with time zone,
    "isNotResponding" boolean DEFAULT false NOT NULL,
    "softwareName" character varying(64),
    "softwareVersion" character varying(64),
    "openRegistrations" boolean,
    name character varying(256),
    description character varying(4096),
    "maintainerName" character varying(128),
    "maintainerEmail" character varying(256),
    "infoUpdatedAt" timestamp with time zone,
    "suspensionState" instance_suspensionstate_enum DEFAULT 'none'::instance_suspensionstate_enum CONSTRAINT "instance_isSuspended_not_null" NOT NULL,
    "iconUrl" character varying(256),
    "themeColor" character varying(64),
    "faviconUrl" character varying(256),
    "moderationNote" character varying(16384) DEFAULT ''::character varying NOT NULL,
    "notRespondingSince" timestamp with time zone,
    "quarantineLimited" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN instance."firstRetrievedAt" IS 'The caught date of the Instance.';

COMMENT ON COLUMN instance.host IS 'The host of the Instance.';

COMMENT ON COLUMN instance."usersCount" IS 'The count of the users of the Instance.';

COMMENT ON COLUMN instance."notesCount" IS 'The count of the notes of the Instance.';

COMMENT ON COLUMN instance."softwareName" IS 'The software of the Instance.';

CREATE TABLE messaging_message (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "recipientId" character varying(32),
    text character varying(4096),
    "isRead" boolean DEFAULT false NOT NULL,
    "fileId" character varying(32),
    "groupId" character varying(32),
    reads character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    uri character varying(512)
);

COMMENT ON COLUMN messaging_message."userId" IS 'The sender user ID.';

COMMENT ON COLUMN messaging_message."recipientId" IS 'The recipient user ID.';

COMMENT ON COLUMN messaging_message."groupId" IS 'The recipient group ID.';

CREATE TABLE meta (
    id character varying(32) NOT NULL,
    name character varying(1024),
    description character varying(1024),
    "maintainerName" character varying(1024),
    "maintainerEmail" character varying(1024),
    "disableRegistration" boolean DEFAULT true NOT NULL,
    langs character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "hiddenTags" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "blockedHosts" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "mascotImageUrl" character varying(1024),
    "bannerUrl" character varying(1024),
    "iconUrl" character varying(1024),
    "cacheRemoteFiles" boolean DEFAULT false NOT NULL,
    "enableRecaptcha" boolean DEFAULT false NOT NULL,
    "recaptchaSiteKey" character varying(1024),
    "recaptchaSecretKey" character varying(1024),
    "urlPreviewSummaryProxyUrl" character varying(1024),
    "enableEmail" boolean DEFAULT false NOT NULL,
    email character varying(1024),
    "smtpSecure" boolean DEFAULT false NOT NULL,
    "smtpHost" character varying(1024),
    "smtpPort" integer,
    "smtpUser" character varying(1024),
    "smtpPass" character varying(1024),
    "enableServiceWorker" boolean DEFAULT false NOT NULL,
    "swPublicKey" character varying(1024),
    "swPrivateKey" character varying(1024),
    "pinnedUsers" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "termsOfServiceUrl" character varying(1024),
    "repositoryUrl" character varying(1024) DEFAULT 'https://github.com/kokonect-link/cherrypick'::character varying,
    "feedbackUrl" character varying(1024) DEFAULT 'https://github.com/kokonect-link/cherrypick/issues/new'::character varying,
    "useObjectStorage" boolean DEFAULT false NOT NULL,
    "objectStorageBucket" character varying(1024),
    "objectStoragePrefix" character varying(1024),
    "objectStorageBaseUrl" character varying(1024),
    "objectStorageEndpoint" character varying(1024),
    "objectStorageRegion" character varying(1024),
    "objectStorageAccessKey" character varying(1024),
    "objectStorageSecretKey" character varying(1024),
    "objectStoragePort" integer,
    "objectStorageUseSSL" boolean DEFAULT true NOT NULL,
    "objectStorageUseProxy" boolean DEFAULT true NOT NULL,
    "enableHcaptcha" boolean DEFAULT false NOT NULL,
    "hcaptchaSiteKey" character varying(1024),
    "hcaptchaSecretKey" character varying(1024),
    "objectStorageSetPublicRead" boolean DEFAULT false NOT NULL,
    "backgroundImageUrl" character varying(1024),
    "logoImageUrl" character varying(1024),
    "objectStorageS3ForcePathStyle" boolean DEFAULT true NOT NULL,
    "deeplAuthKey" character varying(1024),
    "deeplIsPro" boolean DEFAULT false NOT NULL,
    "emailRequiredForSignup" boolean DEFAULT false NOT NULL,
    "themeColor" character varying(1024),
    "defaultLightTheme" character varying(8192),
    "defaultDarkTheme" character varying(8192),
    "sensitiveMediaDetection" meta_sensitivemediadetection_enum DEFAULT 'none'::meta_sensitivemediadetection_enum NOT NULL,
    "sensitiveMediaDetectionSensitivity" meta_sensitivemediadetectionsensitivity_enum DEFAULT 'medium'::meta_sensitivemediadetectionsensitivity_enum NOT NULL,
    "setSensitiveFlagAutomatically" boolean DEFAULT false NOT NULL,
    "enableIpLogging" boolean DEFAULT false NOT NULL,
    "enableSensitiveMediaDetectionForVideos" boolean DEFAULT false NOT NULL,
    "enableActiveEmailValidation" boolean DEFAULT true NOT NULL,
    "translatorType" character varying(1024),
    "enableTurnstile" boolean DEFAULT false NOT NULL,
    "turnstileSiteKey" character varying(1024),
    "turnstileSecretKey" character varying(1024),
    policies jsonb DEFAULT '{}'::jsonb CONSTRAINT "meta_defaultRoleOverride_not_null" NOT NULL,
    "sensitiveWords" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "enableChartsForRemoteUser" boolean DEFAULT true NOT NULL,
    "enableChartsForFederatedInstances" boolean DEFAULT true NOT NULL,
    "serverRules" character varying(280)[] DEFAULT '{}'::character varying[] NOT NULL,
    "preservedUsernames" character varying(1024)[] DEFAULT '{admin,administrator,root,system,maintainer,host,mod,moderator,owner,superuser,staff,auth,i,me,everyone,all,mention,mentions,example,user,users,account,accounts,official,help,helps,support,supports,info,information,informations,announce,announces,announcement,announcements,notice,notification,notifications,dev,developer,developers,tech,misskey,cherrypick}'::character varying[] NOT NULL,
    "ctav3SaKey" character varying(5120),
    "ctav3ProjectId" character varying(1024),
    "ctav3Location" character varying(1024),
    "ctav3Model" character varying(1024),
    "ctav3Glossary" character varying(1024),
    "serverErrorImageUrl" character varying(1024),
    "notFoundImageUrl" character varying(1024),
    "infoImageUrl" character varying(1024),
    "enableServerMachineStats" boolean DEFAULT false NOT NULL,
    "enableIdenticonGeneration" boolean DEFAULT true NOT NULL,
    "cacheRemoteSensitiveFiles" boolean DEFAULT true NOT NULL,
    "emailToReceiveAbuseReport" character varying(1024),
    "doNotSendNotificationEmailsForAbuseReport" boolean DEFAULT false NOT NULL,
    "app192IconUrl" character varying(1024),
    "app512IconUrl" character varying(1024),
    "manifestJsonOverride" character varying(8192) DEFAULT '{}'::character varying NOT NULL,
    "shortName" character varying(64),
    "impressumUrl" character varying(1024),
    "privacyPolicyUrl" character varying(1024),
    "perLocalUserUserTimelineCacheMax" integer DEFAULT 300 NOT NULL,
    "perRemoteUserUserTimelineCacheMax" integer DEFAULT 100 NOT NULL,
    "perUserHomeTimelineCacheMax" integer DEFAULT 300 NOT NULL,
    "perUserListTimelineCacheMax" integer DEFAULT 300 NOT NULL,
    "enableReceivePrerelease" boolean DEFAULT false NOT NULL,
    "skipVersion" boolean DEFAULT false NOT NULL,
    "skipCherryPickVersion" character varying(32),
    "notesPerOneAd" integer DEFAULT 0 NOT NULL,
    "silencedHosts" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "enableFanoutTimeline" boolean DEFAULT true NOT NULL,
    "enableFanoutTimelineDbFallback" boolean DEFAULT true NOT NULL,
    "verifymailAuthKey" character varying(1024),
    "enableVerifymailApi" boolean DEFAULT false NOT NULL,
    "bubbleInstances" character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    "bannedEmailDomains" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "truemailInstance" character varying(1024),
    "truemailAuthKey" character varying(1024),
    "enableTruemailApi" boolean DEFAULT false NOT NULL,
    "enableMcaptcha" boolean DEFAULT false NOT NULL,
    "mcaptchaSitekey" character varying(1024),
    "mcaptchaSecretKey" character varying(1024),
    "mcaptchaInstanceUrl" character varying(1024),
    "prohibitedWords" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "urlPreviewEnabled" boolean DEFAULT true NOT NULL,
    "urlPreviewTimeout" integer DEFAULT 10000 NOT NULL,
    "urlPreviewMaximumContentLength" bigint DEFAULT 10485760 NOT NULL,
    "urlPreviewRequireContentLength" boolean DEFAULT false NOT NULL,
    "urlPreviewUserAgent" character varying(1024),
    "trustedLinkUrlPatterns" character varying(3072)[] DEFAULT '{}'::character varying[] NOT NULL,
    "mediaSilencedHosts" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "inquiryUrl" character varying(1024),
    "customSplashText" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "enableReactionsBuffering" boolean DEFAULT false NOT NULL,
    "enableStatsForFederatedInstances" boolean DEFAULT true NOT NULL,
    federation character varying(128) DEFAULT 'none'::character varying NOT NULL,
    "federationHosts" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "enableTestcaptcha" boolean DEFAULT false NOT NULL,
    "prohibitedWordsForNameOfUser" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "useRemoteObjectStorage" boolean DEFAULT false NOT NULL,
    "remoteObjectStorageBucket" character varying(1024),
    "remoteObjectStoragePrefix" character varying(1024),
    "remoteObjectStorageBaseUrl" character varying(1024),
    "remoteObjectStorageEndpoint" character varying(1024),
    "remoteObjectStorageRegion" character varying(1024),
    "remoteObjectStorageAccessKey" character varying(1024),
    "remoteObjectStorageSecretKey" character varying(1024),
    "remoteObjectStoragePort" integer,
    "remoteObjectStorageUseSSL" boolean DEFAULT true,
    "remoteObjectStorageUseProxy" boolean DEFAULT true,
    "remoteObjectStorageSetPublicRead" boolean DEFAULT false NOT NULL,
    "remoteObjectStorageS3ForcePathStyle" boolean DEFAULT true NOT NULL,
    "youBlockedImageUrl" character varying(1024),
    "disableRegistrationWhenInactive" boolean DEFAULT true NOT NULL,
    "disablePublicNoteWhenInactive" boolean DEFAULT false NOT NULL,
    "moderatorInactivityLimitDays" integer DEFAULT 7 NOT NULL,
    "libreTranslateEndPoint" character varying(1024),
    "libreTranslateApiKey" character varying(1024),
    "customRobotsTxt" character varying(2048),
    "googleAnalyticsMeasurementId" character varying(64),
    "rootUserId" character varying(32),
    "deliverSuspendedSoftware" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "ugcVisibilityForVisitor" character varying(128) DEFAULT 'local'::character varying NOT NULL,
    "singleUserMode" boolean DEFAULT false NOT NULL,
    "proxyRemoteFiles" boolean DEFAULT true NOT NULL,
    "signToActivityPubGet" boolean DEFAULT true NOT NULL,
    "allowExternalApRedirect" boolean DEFAULT true NOT NULL,
    "urlPreviewAllowRedirect" boolean DEFAULT true NOT NULL,
    "enableRemoteNotesCleaning" boolean DEFAULT false NOT NULL,
    "remoteNotesCleaningMaxProcessingDurationInMinutes" integer DEFAULT 60 NOT NULL,
    "remoteNotesCleaningExpiryDaysForEachNotes" integer DEFAULT 90 NOT NULL,
    "clientOptions" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "showRoleBadgesOfRemoteUsers" boolean DEFAULT false NOT NULL,
    "approvalRequiredForSignup" boolean DEFAULT false NOT NULL
);

CREATE TABLE migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);

CREATE SEQUENCE migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE migrations_id_seq OWNED BY migrations.id;

CREATE TABLE moderation_log (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    type character varying(128) NOT NULL,
    info jsonb NOT NULL
);

CREATE TABLE muting (
    id character varying(32) NOT NULL,
    "muteeId" character varying(32) NOT NULL,
    "muterId" character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone
);

COMMENT ON COLUMN muting."muteeId" IS 'The mutee user ID.';

COMMENT ON COLUMN muting."muterId" IS 'The muter user ID.';

CREATE TABLE note (
    id character varying(32) NOT NULL,
    "replyId" character varying(32),
    "renoteId" character varying(32),
    text text,
    name character varying(256),
    cw character varying(512),
    "userId" character varying(32) NOT NULL,
    "localOnly" boolean DEFAULT false NOT NULL,
    "renoteCount" smallint DEFAULT 0 NOT NULL,
    "repliesCount" smallint DEFAULT 0 NOT NULL,
    reactions jsonb DEFAULT '{}'::jsonb NOT NULL,
    visibility note_visibility_enum NOT NULL,
    uri character varying(512),
    "fileIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "attachedFileTypes" character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    "visibleUserIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    mentions character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "mentionedRemoteUsers" text DEFAULT '[]'::text NOT NULL,
    emojis character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    tags character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    "hasPoll" boolean DEFAULT false NOT NULL,
    "userHost" character varying(128),
    "replyUserId" character varying(32),
    "replyUserHost" character varying(128),
    "renoteUserId" character varying(32),
    "renoteUserHost" character varying(128),
    url character varying(512),
    "channelId" character varying(32),
    "disableRightClick" boolean DEFAULT false NOT NULL,
    "threadId" character varying(256),
    "reactionAcceptance" character varying(64),
    "hasEvent" boolean DEFAULT false CONSTRAINT "note_isEvent_not_null" NOT NULL,
    "clippedCount" smallint DEFAULT '0'::smallint NOT NULL,
    "updatedAt" timestamp with time zone,
    "updatedAtHistory" timestamp with time zone[],
    "reactionAndUserPairCache" character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    "deleteAt" timestamp with time zone,
    "deliveryTargets" jsonb,
    "pageCount" smallint DEFAULT '0'::smallint NOT NULL,
    "renoteChannelId" character varying(32)
);

COMMENT ON COLUMN note."replyId" IS 'The ID of reply target.';

COMMENT ON COLUMN note."renoteId" IS 'The ID of renote target.';

COMMENT ON COLUMN note."userId" IS 'The ID of author.';

COMMENT ON COLUMN note.uri IS 'The URI of a note. it will be null when the note is local.';

COMMENT ON COLUMN note."userHost" IS '[Denormalized]';

COMMENT ON COLUMN note."replyUserId" IS '[Denormalized]';

COMMENT ON COLUMN note."replyUserHost" IS '[Denormalized]';

COMMENT ON COLUMN note."renoteUserId" IS '[Denormalized]';

COMMENT ON COLUMN note."renoteUserHost" IS '[Denormalized]';

COMMENT ON COLUMN note.url IS 'The human readable url of a note. it will be null when the note is local.';

COMMENT ON COLUMN note."channelId" IS 'The ID of source channel.';

COMMENT ON COLUMN note."renoteChannelId" IS '[Denormalized]';

CREATE TABLE note_draft (
    id character varying(32) NOT NULL,
    "replyId" character varying(32),
    "renoteId" character varying(32),
    text text,
    cw character varying(512),
    "userId" character varying(32) NOT NULL,
    "localOnly" boolean DEFAULT false NOT NULL,
    "reactionAcceptance" character varying(64),
    visibility note_draft_visibility_enum NOT NULL,
    "fileIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "visibleUserIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    hashtag character varying(128),
    "channelId" character varying(32),
    "hasPoll" boolean DEFAULT false NOT NULL,
    "pollChoices" character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    "pollMultiple" boolean NOT NULL,
    "pollExpiresAt" timestamp with time zone,
    "pollExpiredAfter" bigint,
    "hasEvent" boolean DEFAULT false,
    "eventStart" timestamp with time zone,
    "eventEnd" timestamp with time zone,
    "eventTitle" character varying(128),
    "eventMetadata" jsonb DEFAULT '{}'::jsonb,
    "disableRightClick" boolean DEFAULT false,
    "deleteAt" timestamp with time zone,
    "deliveryTargets" jsonb,
    "scheduledAt" timestamp with time zone,
    "isActuallyScheduled" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN note_draft."replyId" IS 'The ID of reply target.';

COMMENT ON COLUMN note_draft."renoteId" IS 'The ID of renote target.';

COMMENT ON COLUMN note_draft."userId" IS 'The ID of author.';

COMMENT ON COLUMN note_draft."channelId" IS 'The ID of source channel.';

CREATE TABLE note_favorite (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL
);

CREATE TABLE note_history (
    id character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" character varying(32) NOT NULL,
    "fileIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "attachedFileTypes" character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    emojis character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    text text,
    visibility note_history_visibility_enum NOT NULL,
    "visibleUserIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    cw character varying(512),
    poll jsonb,
    event jsonb
);

CREATE TABLE note_reaction (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    reaction character varying(260) NOT NULL
);

CREATE TABLE note_thread_muting (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "threadId" character varying(256) NOT NULL
);

CREATE TABLE note_unread (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    "noteUserId" character varying(32) NOT NULL,
    "isSpecified" boolean NOT NULL,
    "isMentioned" boolean NOT NULL,
    "noteChannelId" character varying(32)
);

COMMENT ON COLUMN note_unread."noteUserId" IS '[Denormalized]';

COMMENT ON COLUMN note_unread."noteChannelId" IS '[Denormalized]';

CREATE TABLE note_watching (
    id character varying(32) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    "noteUserId" character varying(32) NOT NULL
);

COMMENT ON COLUMN note_watching."createdAt" IS 'The created date of the NoteWatching.';

COMMENT ON COLUMN note_watching."userId" IS 'The watcher ID.';

COMMENT ON COLUMN note_watching."noteId" IS 'The target Note ID.';

COMMENT ON COLUMN note_watching."noteUserId" IS '[Denormalized]';

CREATE TABLE page (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    title character varying(256) NOT NULL,
    name character varying(256) NOT NULL,
    summary character varying(256),
    "alignCenter" boolean NOT NULL,
    font character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "eyeCatchingImageId" character varying(32),
    content jsonb DEFAULT '[]'::jsonb NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    visibility page_visibility_enum NOT NULL,
    "visibleUserIds" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "likedCount" integer DEFAULT 0 NOT NULL,
    "hideTitleWhenPinned" boolean DEFAULT false NOT NULL,
    script character varying(16384) DEFAULT ''::character varying NOT NULL
);

COMMENT ON COLUMN page."updatedAt" IS 'The updated date of the Page.';

COMMENT ON COLUMN page."userId" IS 'The ID of author.';

CREATE TABLE page_like (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "pageId" character varying(32) NOT NULL
);

CREATE TABLE password_reset_request (
    id character varying(32) NOT NULL,
    token character varying(256) NOT NULL,
    "userId" character varying(32) NOT NULL
);

CREATE TABLE poll (
    "noteId" character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone,
    multiple boolean NOT NULL,
    choices character varying(256)[] DEFAULT '{}'::character varying[] NOT NULL,
    votes integer[] NOT NULL,
    "noteVisibility" poll_notevisibility_enum NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userHost" character varying(128),
    "channelId" character varying(32)
);

COMMENT ON COLUMN poll."noteVisibility" IS '[Denormalized]';

COMMENT ON COLUMN poll."userId" IS '[Denormalized]';

COMMENT ON COLUMN poll."userHost" IS '[Denormalized]';

COMMENT ON COLUMN poll."channelId" IS '[Denormalized]';

CREATE TABLE poll_vote (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL,
    choice integer NOT NULL
);

CREATE TABLE promo_note (
    "noteId" character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "userId" character varying(32) NOT NULL
);

COMMENT ON COLUMN promo_note."userId" IS '[Denormalized]';

CREATE TABLE promo_read (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL
);

CREATE TABLE registration_ticket (
    id character varying(32) NOT NULL,
    code character varying(64) NOT NULL,
    "expiresAt" timestamp with time zone,
    "usedAt" timestamp with time zone,
    "pendingUserId" character varying(32),
    "createdById" character varying(32),
    "usedById" character varying(32)
);

CREATE TABLE registry_item (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" character varying(32) NOT NULL,
    key character varying(1024) NOT NULL,
    scope character varying(1024)[] DEFAULT '{}'::character varying[] NOT NULL,
    domain character varying(512),
    value jsonb DEFAULT '{}'::jsonb
);

COMMENT ON COLUMN registry_item."updatedAt" IS 'The updated date of the RegistryItem.';

COMMENT ON COLUMN registry_item."userId" IS 'The owner ID.';

COMMENT ON COLUMN registry_item.key IS 'The key of the RegistryItem.';

COMMENT ON COLUMN registry_item.value IS 'The value of the RegistryItem.';

CREATE TABLE relay (
    id character varying(32) NOT NULL,
    inbox character varying(512) NOT NULL,
    status relay_status_enum NOT NULL
);

CREATE TABLE renote_muting (
    id character varying(32) NOT NULL,
    "muteeId" character varying(32) NOT NULL,
    "muterId" character varying(32) NOT NULL
);

COMMENT ON COLUMN renote_muting."muteeId" IS 'The mutee user ID.';

COMMENT ON COLUMN renote_muting."muterId" IS 'The muter user ID.';

CREATE TABLE retention_aggregation (
    id character varying(32) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "userIds" character varying(32)[] NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "usersCount" integer NOT NULL,
    "dateKey" character varying(512) NOT NULL
);

COMMENT ON COLUMN retention_aggregation."createdAt" IS 'The created date of the Note.';

COMMENT ON COLUMN retention_aggregation."updatedAt" IS 'The updated date of the GalleryPost.';

CREATE TABLE reversi_game (
    id character varying(32) NOT NULL,
    "startedAt" timestamp with time zone,
    "user1Id" character varying(32) NOT NULL,
    "user2Id" character varying(32) NOT NULL,
    "user1Ready" boolean DEFAULT false CONSTRAINT "reversi_game_user1Accepted_not_null" NOT NULL,
    "user2Ready" boolean DEFAULT false CONSTRAINT "reversi_game_user2Accepted_not_null" NOT NULL,
    black integer,
    "isStarted" boolean DEFAULT false NOT NULL,
    "isEnded" boolean DEFAULT false NOT NULL,
    "winnerId" character varying(32),
    "surrenderedUserId" character varying(32),
    logs jsonb DEFAULT '[]'::jsonb NOT NULL,
    map character varying(64)[] NOT NULL,
    bw character varying(32) NOT NULL,
    "isLlotheo" boolean DEFAULT false NOT NULL,
    "canPutEverywhere" boolean DEFAULT false NOT NULL,
    "loopedBoard" boolean DEFAULT false NOT NULL,
    form1 jsonb,
    form2 jsonb,
    crc32 character varying(32),
    "timeoutUserId" character varying(32),
    "endedAt" timestamp with time zone,
    "timeLimitForEachTurn" smallint DEFAULT '90'::smallint NOT NULL,
    "noIrregularRules" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN reversi_game."startedAt" IS 'The started date of the ReversiGame.';

COMMENT ON COLUMN reversi_game."endedAt" IS 'The ended date of the ReversiGame.';

CREATE TABLE reversi_matching (
    id character varying(32) NOT NULL,
    "parentId" character varying(32) NOT NULL,
    "childId" character varying(32) NOT NULL
);

CREATE TABLE role (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(256) NOT NULL,
    description character varying(1024) NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "isModerator" boolean DEFAULT false NOT NULL,
    "isAdministrator" boolean DEFAULT false NOT NULL,
    policies jsonb DEFAULT '{}'::jsonb CONSTRAINT role_options_not_null NOT NULL,
    color character varying(256),
    "canEditMembersByModerator" boolean DEFAULT false NOT NULL,
    "lastUsedAt" timestamp with time zone NOT NULL,
    target role_target_enum DEFAULT 'manual'::role_target_enum NOT NULL,
    "condFormula" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "iconUrl" character varying(512),
    "asBadge" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isExplorable" boolean DEFAULT false NOT NULL,
    "preserveAssignmentOnMoveAccount" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN role."updatedAt" IS 'The updated date of the Role.';

COMMENT ON COLUMN role."lastUsedAt" IS 'The last used date of the Role.';

CREATE TABLE role_assignment (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "roleId" character varying(32) NOT NULL,
    "expiresAt" timestamp with time zone
);

COMMENT ON COLUMN role_assignment."userId" IS 'The user ID.';

COMMENT ON COLUMN role_assignment."roleId" IS 'The role ID.';

CREATE TABLE signin (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    ip character varying(128) NOT NULL,
    headers jsonb NOT NULL,
    success boolean NOT NULL
);

CREATE TABLE sw_subscription (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    endpoint character varying(512) NOT NULL,
    auth character varying(256) NOT NULL,
    publickey character varying(128) NOT NULL,
    "sendReadMessage" boolean DEFAULT false NOT NULL
);

CREATE TABLE system_account (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    type character varying(256) NOT NULL
);

CREATE TABLE system_webhook (
    id character varying(32) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "latestSentAt" timestamp with time zone,
    "latestStatus" integer,
    name character varying(255) NOT NULL,
    "on" character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    url character varying(1024) NOT NULL,
    secret character varying(1024) NOT NULL
);

CREATE TABLE used_username (
    username character varying(128) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL
);

CREATE TABLE "user" (
    id character varying(32) NOT NULL,
    "updatedAt" timestamp with time zone,
    "lastFetchedAt" timestamp with time zone,
    username character varying(128) NOT NULL,
    "usernameLower" character varying(128) NOT NULL,
    name character varying(128),
    "followersCount" integer DEFAULT 0 NOT NULL,
    "followingCount" integer DEFAULT 0 NOT NULL,
    "notesCount" integer DEFAULT 0 NOT NULL,
    "avatarId" character varying(32),
    "bannerId" character varying(32),
    tags character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    "isSuspended" boolean DEFAULT false NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    "isBot" boolean DEFAULT false NOT NULL,
    "isCat" boolean DEFAULT false NOT NULL,
    emojis character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    host character varying(128),
    inbox character varying(512),
    "sharedInbox" character varying(512),
    featured character varying(512),
    uri character varying(512),
    token character(16),
    "isExplorable" boolean DEFAULT true NOT NULL,
    "followersUri" character varying(512),
    "lastActiveDate" timestamp with time zone,
    "hideOnlineStatus" boolean DEFAULT false NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "avatarUrl" character varying(1024),
    "bannerUrl" character varying(512),
    "avatarBlurhash" character varying(128),
    "bannerBlurhash" character varying(128),
    "movedToUri" character varying(512),
    "alsoKnownAs" text,
    "movedAt" timestamp with time zone,
    "isHibernated" boolean DEFAULT false NOT NULL,
    "avatarDecorations" jsonb DEFAULT '[]'::jsonb NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    "requireSigninToViewContents" boolean DEFAULT false NOT NULL,
    "makeNotesFollowersOnlyBefore" integer,
    "makeNotesHiddenBefore" integer,
    "setFederationAvatarShape" boolean,
    "isSquareAvatars" boolean,
    "chatScope" character varying(128) DEFAULT 'mutual'::character varying NOT NULL,
    "autoDeleteNotesAfterDays" integer,
    "autoDeleteKeepFavorites" boolean DEFAULT true NOT NULL,
    "canChat" boolean DEFAULT true,
    approved boolean DEFAULT false NOT NULL,
    "signupReason" character varying(1000)
);

COMMENT ON COLUMN "user"."updatedAt" IS 'The updated date of the User.';

COMMENT ON COLUMN "user".username IS 'The username of the User.';

COMMENT ON COLUMN "user"."usernameLower" IS 'The username (lowercased) of the User.';

COMMENT ON COLUMN "user".name IS 'The name of the User.';

COMMENT ON COLUMN "user"."followersCount" IS 'The count of followers.';

COMMENT ON COLUMN "user"."followingCount" IS 'The count of following.';

COMMENT ON COLUMN "user"."notesCount" IS 'The count of notes.';

COMMENT ON COLUMN "user"."avatarId" IS 'The ID of avatar DriveFile.';

COMMENT ON COLUMN "user"."bannerId" IS 'The ID of banner DriveFile.';

COMMENT ON COLUMN "user"."isSuspended" IS 'Whether the User is suspended.';

COMMENT ON COLUMN "user"."isLocked" IS 'Whether the User is locked.';

COMMENT ON COLUMN "user"."isBot" IS 'Whether the User is a bot.';

COMMENT ON COLUMN "user"."isCat" IS 'Whether the User is a cat.';

COMMENT ON COLUMN "user".host IS 'The host of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user".inbox IS 'The inbox URL of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user"."sharedInbox" IS 'The sharedInbox URL of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user".featured IS 'The featured URL of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user".uri IS 'The URI of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user".token IS 'The native access token of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user"."isExplorable" IS 'Whether the User is explorable.';

COMMENT ON COLUMN "user"."followersUri" IS 'The URI of the user Follower Collection. It will be null if the origin of the user is local.';

COMMENT ON COLUMN "user"."isDeleted" IS 'Whether the User is deleted.';

COMMENT ON COLUMN "user"."movedToUri" IS 'The URI of the new account of the User';

COMMENT ON COLUMN "user"."alsoKnownAs" IS 'URIs the user is known as too';

COMMENT ON COLUMN "user"."movedAt" IS 'When the user moved to another account';

CREATE TABLE user_group (
    id character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "isPrivate" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN user_group."userId" IS 'The ID of owner.';

CREATE TABLE user_group_invitation (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userGroupId" character varying(32) NOT NULL
);

COMMENT ON COLUMN user_group_invitation."userId" IS 'The user ID.';

COMMENT ON COLUMN user_group_invitation."userGroupId" IS 'The group ID.';

CREATE TABLE user_group_invite (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userGroupId" character varying(32) NOT NULL
);

CREATE TABLE user_group_joining (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userGroupId" character varying(32) NOT NULL
);

COMMENT ON COLUMN user_group_joining."userId" IS 'The user ID.';

COMMENT ON COLUMN user_group_joining."userGroupId" IS 'The group ID.';

CREATE TABLE user_ip (
    id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "userId" character varying(32) NOT NULL,
    ip character varying(128) NOT NULL,
    "dnsNames" character varying(512)[] DEFAULT '{}'::character varying[] NOT NULL
);

CREATE SEQUENCE user_ip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE user_ip_id_seq OWNED BY user_ip.id;

CREATE TABLE user_keypair (
    "userId" character varying(32) NOT NULL,
    "publicKey" character varying(4096) NOT NULL,
    "privateKey" character varying(4096) NOT NULL
);

CREATE TABLE user_list (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL
);

COMMENT ON COLUMN user_list."userId" IS 'The owner ID.';

COMMENT ON COLUMN user_list.name IS 'The name of the UserList.';

CREATE TABLE user_list_favorite (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "userListId" character varying(32) NOT NULL
);

CREATE TABLE user_list_membership (
    id character varying(32) CONSTRAINT user_list_joining_id_not_null NOT NULL,
    "userId" character varying(32) CONSTRAINT "user_list_joining_userId_not_null" NOT NULL,
    "userListId" character varying(32) CONSTRAINT "user_list_joining_userListId_not_null" NOT NULL,
    "withReplies" boolean DEFAULT false CONSTRAINT "user_list_joining_withReplies_not_null" NOT NULL,
    "userListUserId" character varying(32) NOT NULL
);

COMMENT ON COLUMN user_list_membership."userId" IS 'The user ID.';

COMMENT ON COLUMN user_list_membership."userListId" IS 'The list ID.';

CREATE TABLE user_memo (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "targetUserId" character varying(32) NOT NULL,
    memo character varying(2048) NOT NULL
);

COMMENT ON COLUMN user_memo."userId" IS 'The ID of author.';

COMMENT ON COLUMN user_memo."targetUserId" IS 'The ID of target user.';

COMMENT ON COLUMN user_memo.memo IS 'Memo.';

CREATE TABLE user_note_pining (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    "noteId" character varying(32) NOT NULL
);

CREATE TABLE user_pending (
    id character varying(32) NOT NULL,
    code character varying(128) NOT NULL,
    username character varying(128) NOT NULL,
    email character varying(128) NOT NULL,
    password character varying(128) NOT NULL,
    reason character varying(1000)
);

CREATE TABLE user_profile (
    "userId" character varying(32) NOT NULL,
    location character varying(128),
    birthday character(10),
    description character varying(2048),
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    url character varying(512),
    email character varying(128),
    "emailVerifyCode" character varying(128),
    "emailVerified" boolean DEFAULT false NOT NULL,
    "twoFactorTempSecret" character varying(128),
    "twoFactorSecret" character varying(128),
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    password character varying(128),
    "clientData" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "autoAcceptFollowed" boolean DEFAULT false NOT NULL,
    "alwaysMarkNsfw" boolean DEFAULT false NOT NULL,
    "carefulBot" boolean DEFAULT false NOT NULL,
    "userHost" character varying(128),
    "securityKeysAvailable" boolean DEFAULT false NOT NULL,
    "usePasswordLessLogin" boolean DEFAULT false NOT NULL,
    "pinnedPageId" character varying(32),
    room jsonb DEFAULT '{}'::jsonb NOT NULL,
    "injectFeaturedNote" boolean DEFAULT true NOT NULL,
    "enableWordMute" boolean DEFAULT false NOT NULL,
    "mutedWords" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "noCrawle" boolean DEFAULT false NOT NULL,
    "receiveAnnouncementEmail" boolean DEFAULT true NOT NULL,
    "emailNotificationTypes" jsonb DEFAULT '["follow", "receiveFollowRequest", "groupInvited"]'::jsonb NOT NULL,
    lang character varying(32),
    "mutedInstances" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "publicReactions" boolean DEFAULT true NOT NULL,
    "autoSensitive" boolean DEFAULT false NOT NULL,
    "moderationNote" character varying(8192) DEFAULT ''::character varying NOT NULL,
    achievements jsonb DEFAULT '[]'::jsonb NOT NULL,
    "loggedInDates" character varying(32)[] DEFAULT '{}'::character varying[] NOT NULL,
    "preventAiLearning" boolean DEFAULT true CONSTRAINT "user_profile_preventAiLarning_not_null" NOT NULL,
    "twoFactorBackupSecret" character varying[],
    "verifiedLinks" character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    "notificationRecieveConfig" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "hardMutedWords" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "followingVisibility" user_profile_followingvisibility_enum DEFAULT 'public'::user_profile_followingvisibility_enum NOT NULL,
    "followersVisibility" user_profile_followersvisibility_enum DEFAULT 'public'::user_profile_followersvisibility_enum NOT NULL,
    "followedMessage" character varying(256)
);

COMMENT ON COLUMN user_profile.location IS 'The location of the User.';

COMMENT ON COLUMN user_profile.birthday IS 'The birthday (YYYY-MM-DD) of the User.';

COMMENT ON COLUMN user_profile.description IS 'The description (bio) of the User.';

COMMENT ON COLUMN user_profile.url IS 'Remote URL of the user.';

COMMENT ON COLUMN user_profile.email IS 'The email address of the User.';

COMMENT ON COLUMN user_profile.password IS 'The password hash of the User. It will be null if the origin of the user is local.';

COMMENT ON COLUMN user_profile."clientData" IS 'The client-specific data of the User.';

COMMENT ON COLUMN user_profile."userHost" IS '[Denormalized]';

COMMENT ON COLUMN user_profile.room IS 'The room data of the User.';

COMMENT ON COLUMN user_profile."noCrawle" IS 'Whether reject index by crawler.';

COMMENT ON COLUMN user_profile."mutedInstances" IS 'List of instances muted by the user.';

CREATE TABLE user_publickey (
    "userId" character varying(32) NOT NULL,
    "keyId" character varying(256) NOT NULL,
    "keyPem" character varying(4096) NOT NULL
);

CREATE TABLE user_security_key (
    id character varying NOT NULL,
    "userId" character varying(32) NOT NULL,
    "publicKey" character varying NOT NULL,
    "lastUsed" timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(30) NOT NULL,
    counter bigint DEFAULT '0'::bigint NOT NULL,
    "credentialDeviceType" character varying(32),
    "credentialBackedUp" boolean,
    transports character varying(32)[]
);

COMMENT ON COLUMN user_security_key.id IS 'Variable-length id given to navigator.credentials.get()';

COMMENT ON COLUMN user_security_key."publicKey" IS 'The public key of the UserSecurityKey, hex-encoded.';

COMMENT ON COLUMN user_security_key."lastUsed" IS 'Timestamp of the last time the UserSecurityKey was used.';

COMMENT ON COLUMN user_security_key.name IS 'User-defined name for this key';

COMMENT ON COLUMN user_security_key.counter IS 'The number of times the UserSecurityKey was validated.';

COMMENT ON COLUMN user_security_key."credentialDeviceType" IS 'The type of Backup Eligibility in authenticator data';

COMMENT ON COLUMN user_security_key."credentialBackedUp" IS 'Whether or not the credential has been backed up';

COMMENT ON COLUMN user_security_key.transports IS 'The type of the credential returned by the browser';

CREATE TABLE webhook (
    id character varying(32) NOT NULL,
    "userId" character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    "on" character varying(128)[] DEFAULT '{}'::character varying[] NOT NULL,
    url character varying(1024) NOT NULL,
    secret character varying(1024) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "latestSentAt" timestamp with time zone,
    "latestStatus" integer
);

COMMENT ON COLUMN webhook."userId" IS 'The owner ID.';

COMMENT ON COLUMN webhook.name IS 'The name of the Antenna.';

ALTER TABLE ONLY __chart__active_users ALTER COLUMN id SET DEFAULT nextval('__chart__active_users_id_seq'::regclass);

ALTER TABLE ONLY __chart__ap_request ALTER COLUMN id SET DEFAULT nextval('__chart__ap_request_id_seq'::regclass);

ALTER TABLE ONLY __chart__drive ALTER COLUMN id SET DEFAULT nextval('__chart__drive_id_seq'::regclass);

ALTER TABLE ONLY __chart__federation ALTER COLUMN id SET DEFAULT nextval('__chart__federation_id_seq'::regclass);

ALTER TABLE ONLY __chart__hashtag ALTER COLUMN id SET DEFAULT nextval('__chart__hashtag_id_seq'::regclass);

ALTER TABLE ONLY __chart__instance ALTER COLUMN id SET DEFAULT nextval('__chart__instance_id_seq'::regclass);

ALTER TABLE ONLY __chart__network ALTER COLUMN id SET DEFAULT nextval('__chart__network_id_seq'::regclass);

ALTER TABLE ONLY __chart__notes ALTER COLUMN id SET DEFAULT nextval('__chart__notes_id_seq'::regclass);

ALTER TABLE ONLY __chart__per_user_drive ALTER COLUMN id SET DEFAULT nextval('__chart__per_user_drive_id_seq'::regclass);

ALTER TABLE ONLY __chart__per_user_following ALTER COLUMN id SET DEFAULT nextval('__chart__per_user_following_id_seq'::regclass);

ALTER TABLE ONLY __chart__per_user_notes ALTER COLUMN id SET DEFAULT nextval('__chart__per_user_notes_id_seq'::regclass);

ALTER TABLE ONLY __chart__per_user_pv ALTER COLUMN id SET DEFAULT nextval('__chart__per_user_pv_id_seq'::regclass);

ALTER TABLE ONLY __chart__per_user_reaction ALTER COLUMN id SET DEFAULT nextval('__chart__per_user_reaction_id_seq'::regclass);

ALTER TABLE ONLY __chart__test ALTER COLUMN id SET DEFAULT nextval('__chart__test_id_seq'::regclass);

ALTER TABLE ONLY __chart__test_grouped ALTER COLUMN id SET DEFAULT nextval('__chart__test_grouped_id_seq'::regclass);

ALTER TABLE ONLY __chart__test_unique ALTER COLUMN id SET DEFAULT nextval('__chart__test_unique_id_seq'::regclass);

ALTER TABLE ONLY __chart__users ALTER COLUMN id SET DEFAULT nextval('__chart__users_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__active_users ALTER COLUMN id SET DEFAULT nextval('__chart_day__active_users_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__ap_request ALTER COLUMN id SET DEFAULT nextval('__chart_day__ap_request_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__drive ALTER COLUMN id SET DEFAULT nextval('__chart_day__drive_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__federation ALTER COLUMN id SET DEFAULT nextval('__chart_day__federation_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__hashtag ALTER COLUMN id SET DEFAULT nextval('__chart_day__hashtag_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__instance ALTER COLUMN id SET DEFAULT nextval('__chart_day__instance_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__network ALTER COLUMN id SET DEFAULT nextval('__chart_day__network_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__notes ALTER COLUMN id SET DEFAULT nextval('__chart_day__notes_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_drive ALTER COLUMN id SET DEFAULT nextval('__chart_day__per_user_drive_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_following ALTER COLUMN id SET DEFAULT nextval('__chart_day__per_user_following_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_notes ALTER COLUMN id SET DEFAULT nextval('__chart_day__per_user_notes_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_pv ALTER COLUMN id SET DEFAULT nextval('__chart_day__per_user_pv_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_reaction ALTER COLUMN id SET DEFAULT nextval('__chart_day__per_user_reaction_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__users ALTER COLUMN id SET DEFAULT nextval('__chart_day__users_id_seq'::regclass);

ALTER TABLE ONLY migrations ALTER COLUMN id SET DEFAULT nextval('migrations_id_seq'::regclass);

ALTER TABLE ONLY user_ip ALTER COLUMN id SET DEFAULT nextval('user_ip_id_seq'::regclass);

ALTER TABLE ONLY __chart_day__per_user_pv
    ADD CONSTRAINT "PK_0085d7542f6772e99b9dcfb0a9c" PRIMARY KEY (id);

ALTER TABLE ONLY ad
    ADD CONSTRAINT "PK_0193d5ef09746e88e9ea92c634d" PRIMARY KEY (id);

ALTER TABLE ONLY abuse_report_resolver
    ADD CONSTRAINT "PK_093500bf1bb38880d38b1bb41dc" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__notes
    ADD CONSTRAINT "PK_0aec823fa85c7f901bdb3863b14" PRIMARY KEY (id);

ALTER TABLE ONLY flash
    ADD CONSTRAINT "PK_0c01a2c1c5f2266942dd1b3fdbc" PRIMARY KEY (id);

ALTER TABLE ONLY user_publickey
    ADD CONSTRAINT "PK_10c146e4b39b443ede016f6736d" PRIMARY KEY ("userId");

ALTER TABLE ONLY user_list_membership
    ADD CONSTRAINT "PK_11abb3768da1c5f8de101c9df45" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__instance
    ADD CONSTRAINT "PK_1267c67c7c2d47b4903975f2c00" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__hashtag
    ADD CONSTRAINT "PK_13d5a3b089344e5557f8e0980b4" PRIMARY KEY (id);

ALTER TABLE ONLY user_group_joining
    ADD CONSTRAINT "PK_15f2425885253c5507e1599cfe7" PRIMARY KEY (id);

ALTER TABLE ONLY user_group_invitation
    ADD CONSTRAINT "PK_160c63ec02bf23f6a5c5e8140d6" PRIMARY KEY (id);

ALTER TABLE ONLY note_unread
    ADD CONSTRAINT "PK_1904eda61a784f57e6e51fa9c1f" PRIMARY KEY (id);

ALTER TABLE ONLY auth_session
    ADD CONSTRAINT "PK_19354ed146424a728c1112a8cbf" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__per_user_drive
    ADD CONSTRAINT "PK_1ae135254c137011645da7f4045" PRIMARY KEY (id);

ALTER TABLE ONLY clip_favorite
    ADD CONSTRAINT "PK_1b539f43906f05ebcabe752a977" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__notes
    ADD CONSTRAINT "PK_1fa4139e1f338272b758d05e090" PRIMARY KEY (id);

ALTER TABLE ONLY retention_aggregation
    ADD CONSTRAINT "PK_22aad3e8640b15fb3b90ee02d18" PRIMARY KEY (id);

ALTER TABLE ONLY event
    ADD CONSTRAINT "PK_2b481f231cd035e84390072bf7b" PRIMARY KEY ("noteId");

ALTER TABLE ONLY chat_room_membership
    ADD CONSTRAINT "PK_2bd59c741e571b283c048beb69a" PRIMARY KEY (id);

ALTER TABLE ONLY user_ip
    ADD CONSTRAINT "PK_2c44ddfbf7c0464d028dcef325e" PRIMARY KEY (id);

ALTER TABLE ONLY muting
    ADD CONSTRAINT "PK_2e92d06c8b5c602eeb27ca9ba48" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__active_users
    ADD CONSTRAINT "PK_317237a9f733b970604a11e314f" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__per_user_notes
    ADD CONSTRAINT "PK_334acf6e915af2f29edc11b8e50" PRIMARY KEY (id);

ALTER TABLE ONLY user_group_invite
    ADD CONSTRAINT "PK_3893884af0d3a5f4d01e7921a97" PRIMARY KEY (id);

ALTER TABLE ONLY user_group
    ADD CONSTRAINT "PK_3c29fba6fe013ec8724378ce7c9" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__per_user_pv
    ADD CONSTRAINT "PK_3c938a24f0203b5bd13fab51059" PRIMARY KEY (id);

ALTER TABLE ONLY chat_message
    ADD CONSTRAINT "PK_3cc0d85193aade457d3077dd06b" PRIMARY KEY (id);

ALTER TABLE ONLY user_security_key
    ADD CONSTRAINT "PK_3e508571121ab39c5f85d10c166" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__test_unique
    ADD CONSTRAINT "PK_409bac9c97cc612d8500012319d" PRIMARY KEY (id);

ALTER TABLE ONLY drive_file
    ADD CONSTRAINT "PK_43ddaaaf18c9e68029b7cbb032e" PRIMARY KEY (id);

ALTER TABLE ONLY channel_note_pining
    ADD CONSTRAINT "PK_44f7474496bcf2e4b741681146d" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__instance
    ADD CONSTRAINT "PK_479a8ff9d959274981087043023" PRIMARY KEY (id);

ALTER TABLE ONLY note_watching
    ADD CONSTRAINT "PK_49286fdb23725945a74aa27d757" PRIMARY KEY (id);

ALTER TABLE ONLY announcement_read
    ADD CONSTRAINT "PK_4b90ad1f42681d97b2683890c5e" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__users
    ADD CONSTRAINT "PK_4dfcf2c78d03524b9eb2c99d328" PRIMARY KEY (id);

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT "PK_51cb79b5555effaf7d69ba1cff9" PRIMARY KEY ("userId");

ALTER TABLE ONLY follow_request
    ADD CONSTRAINT "PK_53a9aa3725f7a3deb150b39dbfc" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__ap_request
    ADD CONSTRAINT "PK_56a25cd447c7ee08876b3baf8d8" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__per_user_notes
    ADD CONSTRAINT "PK_58bab6b6d3ad9310cbc7460fd28" PRIMARY KEY (id);

ALTER TABLE ONLY channel
    ADD CONSTRAINT "PK_590f33ee6ee7d76437acf362e39" PRIMARY KEY (id);

ALTER TABLE ONLY channel_favorite
    ADD CONSTRAINT "PK_59bddfd54d48689a298d41af00c" PRIMARY KEY (id);

ALTER TABLE ONLY promo_read
    ADD CONSTRAINT "PK_61917c1541002422b703318b7c9" PRIMARY KEY (id);

ALTER TABLE ONLY registry_item
    ADD CONSTRAINT "PK_64b3f7e6008b4d89b826cd3af95" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__per_user_following
    ADD CONSTRAINT "PK_68ce6b67da57166da66fc8fb27e" PRIMARY KEY (id);

ALTER TABLE ONLY page
    ADD CONSTRAINT "PK_742f4117e065c5b6ad21b37ba1f" PRIMARY KEY (id);

ALTER TABLE ONLY note_reaction
    ADD CONSTRAINT "PK_767ec729b108799b587a3fcc9cf" PRIMARY KEY (id);

ALTER TABLE ONLY reversi_game
    ADD CONSTRAINT "PK_76b30eeba71b1193ad7c5311c3f" PRIMARY KEY (id);

ALTER TABLE ONLY relay
    ADD CONSTRAINT "PK_78ebc9cfddf4292633b7ba57aee" PRIMARY KEY (id);

ALTER TABLE ONLY used_username
    ADD CONSTRAINT "PK_78fd79d2d24c6ac2f4cc9a31a5d" PRIMARY KEY (username);

ALTER TABLE ONLY drive_folder
    ADD CONSTRAINT "PK_7a0c089191f5ebdc214e0af808a" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__federation
    ADD CONSTRAINT "PK_7ca721c769f31698e0e1331e8e6" PRIMARY KEY (id);

ALTER TABLE ONLY role_assignment
    ADD CONSTRAINT "PK_7e79671a8a5db18936173148cb4" PRIMARY KEY (id);

ALTER TABLE ONLY page_like
    ADD CONSTRAINT "PK_813f034843af992d3ae0f43c64c" PRIMARY KEY (id);

ALTER TABLE ONLY gallery_like
    ADD CONSTRAINT "PK_853ab02be39b8de45cd720cc15f" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__per_user_following
    ADD CONSTRAINT "PK_85bb1b540363a29c2fec83bd907" PRIMARY KEY (id);

ALTER TABLE ONLY abuse_user_report
    ADD CONSTRAINT "PK_87873f5f5cc5c321a1306b2d18c" PRIMARY KEY (id);

ALTER TABLE ONLY user_list
    ADD CONSTRAINT "PK_87bab75775fd9b1ff822b656402" PRIMARY KEY (id);

ALTER TABLE ONLY reversi_matching
    ADD CONSTRAINT "PK_880bd0afbab232f21c8b9d146cf" PRIMARY KEY (id);

ALTER TABLE ONLY chat_room
    ADD CONSTRAINT "PK_8aa3a52cf74c96469f0ef9fbe3e" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__per_user_reaction
    ADD CONSTRAINT "PK_8af24e2d51ff781a354fe595eda" PRIMARY KEY (id);

ALTER TABLE ONLY channel_following
    ADD CONSTRAINT "PK_8b104be7f7415113f2a02cd5bdd" PRIMARY KEY (id);

ALTER TABLE ONLY migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);

ALTER TABLE ONLY gallery_post
    ADD CONSTRAINT "PK_8e90d7b6015f2c4518881b14753" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__ap_request
    ADD CONSTRAINT "PK_9318b49daee320194e23f712e69" PRIMARY KEY (id);

ALTER TABLE ONLY app
    ADD CONSTRAINT "PK_9478629fc093d229df09e560aea" PRIMARY KEY (id);

ALTER TABLE ONLY note
    ADD CONSTRAINT "PK_96d0c172a4fba276b1bbed43058" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__per_user_reaction
    ADD CONSTRAINT "PK_984f54dae441e65b633e8d27a7f" PRIMARY KEY (id);

ALTER TABLE ONLY chat_room_invitation
    ADD CONSTRAINT "PK_9d489521a312dd28225672de2dc" PRIMARY KEY (id);

ALTER TABLE ONLY signin
    ADD CONSTRAINT "PK_9e96ddc025712616fc492b3b588" PRIMARY KEY (id);

ALTER TABLE ONLY user_note_pining
    ADD CONSTRAINT "PK_a6a2dad4ae000abce2ea9d9b103" PRIMARY KEY (id);

ALTER TABLE ONLY bubble_game_record
    ADD CONSTRAINT "PK_a75395fe404b392e2893b50d7ea" PRIMARY KEY (id);

ALTER TABLE ONLY abuse_report_notification_recipient
    ADD CONSTRAINT "PK_abuse_report_notification_recipient_id" PRIMARY KEY (id);

ALTER TABLE ONLY channel_muting
    ADD CONSTRAINT "PK_aec842e98f332ebd8e12f85bad6" PRIMARY KEY (id);

ALTER TABLE ONLY note_favorite
    ADD CONSTRAINT "PK_af0da35a60b9fa4463a62082b36" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__active_users
    ADD CONSTRAINT "PK_b1790489b14f005ae8f404f5795" PRIMARY KEY (id);

ALTER TABLE ONLY role
    ADD CONSTRAINT "PK_b36bcfe02fc8de3c57a8b2391c2" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__federation
    ADD CONSTRAINT "PK_b39dcd31a0fe1a7757e348e85fd" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__test
    ADD CONSTRAINT "PK_b4bc31dffbd1b785276a3ecfc1e" PRIMARY KEY (id);

ALTER TABLE ONLY avatar_decoration
    ADD CONSTRAINT "PK_b6de9296f6097078e1dc53f7603" PRIMARY KEY (id);

ALTER TABLE ONLY note_history
    ADD CONSTRAINT "PK_b8603c8aa42b803c7687e52c2c0" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__network
    ADD CONSTRAINT "PK_bc4290c2e27fad14ef0c1ca93f3" PRIMARY KEY (id);

ALTER TABLE ONLY user_list_favorite
    ADD CONSTRAINT "PK_c0974b21e18502a4c8178e09fe6" PRIMARY KEY (id);

ALTER TABLE ONLY antenna
    ADD CONSTRAINT "PK_c170b99775e1dccca947c9f2d5f" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__hashtag
    ADD CONSTRAINT "PK_c32f1ea2b44a5d2f7881e37f8f9" PRIMARY KEY (id);

ALTER TABLE ONLY meta
    ADD CONSTRAINT "PK_c4c17a6c2bd7651338b60fc590b" PRIMARY KEY (id);

ALTER TABLE ONLY following
    ADD CONSTRAINT "PK_c76c6e044bdf76ecf8bfb82a645" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__network
    ADD CONSTRAINT "PK_cac499d6f471042dfed1e7e0132" PRIMARY KEY (id);

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);

ALTER TABLE ONLY hashtag
    ADD CONSTRAINT "PK_cb36eb8af8412bfa978f1165d78" PRIMARY KEY (id);

ALTER TABLE ONLY moderation_log
    ADD CONSTRAINT "PK_d0adca6ecfd068db83e4526cc26" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__per_user_drive
    ADD CONSTRAINT "PK_d0ef23d24d666e1a44a0cd3d208" PRIMARY KEY (id);

ALTER TABLE ONLY flash_like
    ADD CONSTRAINT "PK_d110109ee310588d63d6183b233" PRIMARY KEY (id);

ALTER TABLE ONLY user_pending
    ADD CONSTRAINT "PK_d4c84e013c98ec02d19b8fbbafa" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__users
    ADD CONSTRAINT "PK_d7f7185abb9851f70c4726c54bd" PRIMARY KEY (id);

ALTER TABLE ONLY poll
    ADD CONSTRAINT "PK_da851e06d0dfe2ef397d8b1bf1b" PRIMARY KEY ("noteId");

ALTER TABLE ONLY messaging_message
    ADD CONSTRAINT "PK_db398fd79dc95d0eb8c30456eaa" PRIMARY KEY (id);

ALTER TABLE ONLY emoji
    ADD CONSTRAINT "PK_df74ce05e24999ee01ea0bc50a3" PRIMARY KEY (id);

ALTER TABLE ONLY announcement
    ADD CONSTRAINT "PK_e0ef0550174fd1099a308fd18a0" PRIMARY KEY (id);

ALTER TABLE ONLY promo_note
    ADD CONSTRAINT "PK_e263909ca4fe5d57f8d4230dd5c" PRIMARY KEY ("noteId");

ALTER TABLE ONLY blocking
    ADD CONSTRAINT "PK_e5d9a541cc1965ee7e048ea09dd" PRIMARY KEY (id);

ALTER TABLE ONLY webhook
    ADD CONSTRAINT "PK_e6765510c2d078db49632b59020" PRIMARY KEY (id);

ALTER TABLE ONLY __chart_day__drive
    ADD CONSTRAINT "PK_e7ec0de057c77c40fc8d8b62151" PRIMARY KEY (id);

ALTER TABLE ONLY sw_subscription
    ADD CONSTRAINT "PK_e8f763631530051b95eb6279b91" PRIMARY KEY (id);

ALTER TABLE ONLY clip_note
    ADD CONSTRAINT "PK_e94cda2f40a99b57e032a1a738b" PRIMARY KEY (id);

ALTER TABLE ONLY user_memo
    ADD CONSTRAINT "PK_e9aaa58f7d3699a84d79078f4d9" PRIMARY KEY (id);

ALTER TABLE ONLY instance
    ADD CONSTRAINT "PK_eaf60e4a0c399c9935413e06474" PRIMARY KEY (id);

ALTER TABLE ONLY note_thread_muting
    ADD CONSTRAINT "PK_ec5936d94d1a0369646d12a3a47" PRIMARY KEY (id);

ALTER TABLE ONLY system_account
    ADD CONSTRAINT "PK_edb56f4aaf9ddd50ee556da97ba" PRIMARY KEY (id);

ALTER TABLE ONLY clip
    ADD CONSTRAINT "PK_f0685dac8d4dd056d7255670b75" PRIMARY KEY (id);

ALTER TABLE ONLY registration_ticket
    ADD CONSTRAINT "PK_f11696b6fafcf3662d4292734f8" PRIMARY KEY (id);

ALTER TABLE ONLY access_token
    ADD CONSTRAINT "PK_f20f028607b2603deabd8182d12" PRIMARY KEY (id);

ALTER TABLE ONLY user_keypair
    ADD CONSTRAINT "PK_f4853eb41ab722fe05f81cedeb6" PRIMARY KEY ("userId");

ALTER TABLE ONLY __chart__test_grouped
    ADD CONSTRAINT "PK_f4a2b175d308695af30d4293272" PRIMARY KEY (id);

ALTER TABLE ONLY __chart__drive
    ADD CONSTRAINT "PK_f96bc548a765cd4b3b354221ce7" PRIMARY KEY (id);

ALTER TABLE ONLY chat_approval
    ADD CONSTRAINT "PK_fbbb95d60acf5c85388345b5f5d" PRIMARY KEY (id);

ALTER TABLE ONLY password_reset_request
    ADD CONSTRAINT "PK_fcf4b02eae1403a2edaf87fd074" PRIMARY KEY (id);

ALTER TABLE ONLY poll_vote
    ADD CONSTRAINT "PK_fd002d371201c472490ba89c6a0" PRIMARY KEY (id);

ALTER TABLE ONLY renote_muting
    ADD CONSTRAINT "PK_renoteMuting_id" PRIMARY KEY (id);

ALTER TABLE ONLY system_webhook
    ADD CONSTRAINT "PK_system_webhook_id" PRIMARY KEY (id);

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "REL_58f5c71eaab331645112cf8cfa" UNIQUE ("avatarId");

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "REL_afc64b53f8db3707ceb34eb28e" UNIQUE ("bannerId");

ALTER TABLE ONLY __chart__active_users
    ADD CONSTRAINT "UQ_0ad37b7ef50f4ddc84363d7ccca" UNIQUE (date);

ALTER TABLE ONLY __chart_day__drive
    ADD CONSTRAINT "UQ_0b60ebb3aa0065f10b0616c1171" UNIQUE (date);

ALTER TABLE ONLY user_publickey
    ADD CONSTRAINT "UQ_10c146e4b39b443ede016f6736d" UNIQUE ("userId");

ALTER TABLE ONLY __chart__drive
    ADD CONSTRAINT "UQ_13565815f618a1ff53886c5b28a" UNIQUE (date);

ALTER TABLE ONLY __chart_day__notes
    ADD CONSTRAINT "UQ_1a527b423ad0858a1af5a056d43" UNIQUE (date);

ALTER TABLE ONLY __chart__per_user_reaction
    ADD CONSTRAINT "UQ_229a41ad465f9205f1f57032910" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__hashtag
    ADD CONSTRAINT "UQ_25a97c02003338124b2b75fdbc8" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__per_user_drive
    ADD CONSTRAINT "UQ_30bf67687f483ace115c5ca6429" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__federation
    ADD CONSTRAINT "UQ_36cb699c49580d4e6c2e6159f97" UNIQUE (date);

ALTER TABLE ONLY __chart__instance
    ADD CONSTRAINT "UQ_39ee857ab2f23493037c6b66311" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__notes
    ADD CONSTRAINT "UQ_42eb716a37d381cdf566192b2be" UNIQUE (date);

ALTER TABLE ONLY __chart__per_user_notes
    ADD CONSTRAINT "UQ_5048e9daccbbbc6d567bb142d34" UNIQUE (date, "group");

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT "UQ_51cb79b5555effaf7d69ba1cff9" UNIQUE ("userId");

ALTER TABLE ONLY __chart_day__federation
    ADD CONSTRAINT "UQ_617a8fe225a6e701d89e02d2c74" UNIQUE (date);

ALTER TABLE ONLY __chart_day__per_user_drive
    ADD CONSTRAINT "UQ_62aa5047b5aec92524f24c701d7" UNIQUE (date, "group");

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT "UQ_6dc44f1ceb65b1e72bacef2ca27" UNIQUE ("pinnedPageId");

ALTER TABLE ONLY __chart__users
    ADD CONSTRAINT "UQ_845254b3eaf708ae8a6cac30265" UNIQUE (date);

ALTER TABLE ONLY __chart_day__network
    ADD CONSTRAINT "UQ_8bfa548c2b31f9e07db113773ee" UNIQUE (date);

ALTER TABLE ONLY __chart_day__hashtag
    ADD CONSTRAINT "UQ_8f589cf056ff51f09d6096f6450" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__network
    ADD CONSTRAINT "UQ_a1efd3e0048a5f2793a47360dc6" UNIQUE (date);

ALTER TABLE ONLY __chart_day__ap_request
    ADD CONSTRAINT "UQ_a848f66d6cec11980a5dd595822" UNIQUE (date);

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "UQ_a854e557b1b14814750c7c7b0c9" UNIQUE (token);

ALTER TABLE ONLY registration_ticket
    ADD CONSTRAINT "UQ_b6f93f2f30bdbb9a5ebdc7c7189" UNIQUE ("usedById");

ALTER TABLE ONLY __chart__per_user_following
    ADD CONSTRAINT "UQ_b77d4dd9562c3a899d9a286fcd7" UNIQUE (date, "group");

ALTER TABLE ONLY __chart_day__per_user_notes
    ADD CONSTRAINT "UQ_c5545d4b31cdc684034e33b81c3" UNIQUE (date, "group");

ALTER TABLE ONLY __chart_day__users
    ADD CONSTRAINT "UQ_cad6e07c20037f31cdba8a350c3" UNIQUE (date);

ALTER TABLE ONLY __chart_day__per_user_reaction
    ADD CONSTRAINT "UQ_d54b653660d808b118e36c184c0" UNIQUE (date, "group");

ALTER TABLE ONLY __chart_day__active_users
    ADD CONSTRAINT "UQ_d5954f3df5e5e3bdfc3c03f3906" UNIQUE (date);

ALTER TABLE ONLY poll
    ADD CONSTRAINT "UQ_da851e06d0dfe2ef397d8b1bf1b" UNIQUE ("noteId");

ALTER TABLE ONLY promo_note
    ADD CONSTRAINT "UQ_e263909ca4fe5d57f8d4230dd5c" UNIQUE ("noteId");

ALTER TABLE ONLY __chart_day__per_user_following
    ADD CONSTRAINT "UQ_e4849a3231f38281280ea4c0eee" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__ap_request
    ADD CONSTRAINT "UQ_e56f4beac5746d44bc3e19c80d0" UNIQUE (date);

ALTER TABLE ONLY __chart_day__per_user_pv
    ADD CONSTRAINT "UQ_f221e45cfac5bea0ce0f3149fbb" UNIQUE (date, "group");

ALTER TABLE ONLY __chart__per_user_pv
    ADD CONSTRAINT "UQ_f2a56da57921ca8439f45c1d95f" UNIQUE (date, "group");

ALTER TABLE ONLY user_keypair
    ADD CONSTRAINT "UQ_f4853eb41ab722fe05f81cedeb6" UNIQUE ("userId");

ALTER TABLE ONLY __chart_day__instance
    ADD CONSTRAINT "UQ_fea7c0278325a1a2492f2d6acbf" UNIQUE (date, "group");

ALTER TABLE ONLY note_draft
    ADD CONSTRAINT note_draft_pkey PRIMARY KEY (id);

CREATE INDEX "IDX_00ceffb0cdc238b3233294f08f" ON drive_folder USING btree ("parentId");

CREATE INDEX "IDX_016f613dc4feb807e03e3e7da9" ON user_list_favorite USING btree ("userId");

CREATE INDEX "IDX_01cd2b829e0263917bf570cb67" ON event USING btree ("userId");

CREATE INDEX "IDX_021015e6683570ae9f6b0c62be" ON user_list_membership USING btree ("userId");

CREATE INDEX "IDX_03e7028ab8388a3f5e3ce2a861" ON note_watching USING btree ("noteId");

CREATE UNIQUE INDEX "IDX_044f2a7962b8ee5bbfaa02e8a3" ON chat_room_invitation USING btree ("userId", "roomId");

CREATE INDEX "IDX_04cc96756f89d0b7f9473e8cdf" ON abuse_user_report USING btree ("reporterId");

CREATE INDEX "IDX_05cca34b985d1b8edc1d1e28df" ON gallery_post USING btree (tags);

CREATE INDEX "IDX_0610ebcfcfb4a18441a9bcdab2" ON poll USING btree ("userId");

CREATE INDEX "IDX_0627125f1a8a42c9a1929edb55" ON blocking USING btree ("blockerId");

CREATE INDEX "IDX_084c2abb8948ef59a37dce6ac1" ON antenna USING btree ("lastUsedAt");

CREATE INDEX "IDX_094b86cd36bb805d1aa1e8cc9a" ON channel USING btree ("usersCount");

CREATE UNIQUE INDEX "IDX_0953deda7ce6e1448e935859e5" ON role_assignment USING btree ("userId", "roleId");

CREATE INDEX "IDX_09f4e5b9e4a2f268d3e284e4b3" ON retention_aggregation USING btree ("createdAt");

CREATE INDEX "IDX_0a72bdfcdb97c0eca11fe7ecad" ON registry_item USING btree (domain);

CREATE UNIQUE INDEX "IDX_0ad37b7ef50f4ddc84363d7ccc" ON __chart__active_users USING btree (date);

CREATE INDEX "IDX_0b03cbcd7e6a7ce068efa8ecc2" ON hashtag USING btree ("attachedRemoteUsersCount");

CREATE UNIQUE INDEX "IDX_0b575fa9a4cfe638a925949285" ON password_reset_request USING btree (token);

CREATE UNIQUE INDEX "IDX_0b60ebb3aa0065f10b0616c117" ON __chart_day__drive USING btree (date);

CREATE INDEX "IDX_0c44bf4f680964145f2a68a341" ON hashtag USING btree ("attachedLocalUsersCount");

CREATE INDEX "IDX_0d7718e562dcedd0aa5cf2c9f7" ON user_security_key USING btree ("publicKey");

CREATE UNIQUE INDEX "IDX_0d9a1738f2cf7f3b1c3334dfab" ON relay USING btree (inbox);

CREATE INDEX "IDX_0e206cec573f1edff4a3062923" ON hashtag USING btree ("mentionedLocalUsersCount");

CREATE INDEX "IDX_0e43068c3f92cab197c3d3cd86" ON channel_following USING btree ("followeeId");

CREATE INDEX "IDX_0e61efab7f88dbb79c9166dbb4" ON page_like USING btree ("userId");

CREATE UNIQUE INDEX "IDX_0f4fb9ad355f3effff221ef245" ON note_favorite USING btree ("userId", "noteId");

CREATE INDEX "IDX_0f58c11241e649d2a638a8de94" ON channel USING btree ("notesCount");

CREATE UNIQUE INDEX "IDX_0ff69e8dfa9fe31bb4a4660f59" ON registration_ticket USING btree (code);

CREATE INDEX "IDX_1039988afa3bf991185b277fe0" ON user_group_invite USING btree ("userId");

CREATE INDEX "IDX_12c01c0d1a79f77d9f6c15fadd" ON follow_request USING btree ("followeeId");

CREATE UNIQUE INDEX "IDX_12c4768a2f706fc267f2078903" ON chat_approval USING btree ("userId", "otherId");

CREATE UNIQUE INDEX "IDX_13565815f618a1ff53886c5b28" ON __chart__drive USING btree (date);

CREATE INDEX "IDX_13761f64257f40c5636d0ff95e" ON note_reaction USING btree ("userId");

CREATE UNIQUE INDEX "IDX_153536c67d05e9adb24e99fc2b" ON note USING btree (uri);

CREATE UNIQUE INDEX "IDX_16effb2e888f6763673b579f80" ON __chart__test_unique USING btree (date) WHERE ("group" IS NULL);

CREATE UNIQUE INDEX "IDX_171e64971c780ebd23fae140bb" ON user_publickey USING btree ("keyId");

CREATE INDEX "IDX_17cb3553c700a4985dff5a30ff" ON note USING btree ("replyId");

CREATE UNIQUE INDEX "IDX_185b6b5afa707b5d36d1ce3144" ON chat_room_membership USING btree ("userId", "roomId");

CREATE INDEX "IDX_1a165c68a49d08f11caffbd206" ON gallery_post USING btree ("likedCount");

CREATE UNIQUE INDEX "IDX_1a527b423ad0858a1af5a056d4" ON __chart_day__notes USING btree (date);

CREATE INDEX "IDX_1e2492ba7582bf830b750a2962" ON note_history USING btree ("noteId");

CREATE UNIQUE INDEX "IDX_1eb9d9824a630321a29fd3b290" ON muting USING btree ("muterId", "muteeId");

CREATE UNIQUE INDEX "IDX_2133ef8317e4bdb839c0dcbf13" ON page USING btree ("userId", name);

CREATE UNIQUE INDEX "IDX_229a41ad465f9205f1f5703291" ON __chart__per_user_reaction USING btree (date, "group");

CREATE INDEX "IDX_22baca135bb8a3ea1a83d13df3" ON registry_item USING btree (scope);

CREATE INDEX "IDX_24e0042143a18157b234df186c" ON following USING btree ("followeeId");

CREATE INDEX "IDX_25a31662b0b0cc9af6549a9d71" ON clip_favorite USING btree ("userId");

CREATE UNIQUE INDEX "IDX_25a97c02003338124b2b75fdbc" ON __chart__hashtag USING btree (date, "group");

CREATE INDEX "IDX_25b1dd384bec391b07b74b861c" ON note_unread USING btree ("isMentioned");

CREATE INDEX "IDX_25e097b51d7622c249452c6f75" ON chat_message USING btree ("toUserId");

CREATE INDEX "IDX_26d4ee490b5a487142d35466ee" ON bubble_game_record USING btree (score);

CREATE INDEX "IDX_2710a55f826ee236ea1a62698f" ON hashtag USING btree ("mentionedUsersCount");

CREATE UNIQUE INDEX "IDX_2882b8a1a07c7d281a98b6db16" ON promo_read USING btree ("userId", "noteId");

CREATE INDEX "IDX_29c11c7deb06615076f8c95b80" ON note_thread_muting USING btree ("userId");

CREATE INDEX "IDX_29e8c1d579af54d4232939f994" ON note_unread USING btree ("noteUserId");

CREATE INDEX "IDX_29ef80c6f13bcea998447fce43" ON channel USING btree ("lastNotedAt");

CREATE INDEX "IDX_2b15aaf4a0dc5be3499af7ab6a" ON abuse_user_report USING btree (resolved);

CREATE INDEX "IDX_2b5ec6c574d6802c94c80313fb" ON clip USING btree ("userId");

CREATE INDEX "IDX_2c308dbdc50d94dc625670055f" ON signin USING btree ("userId");

CREATE INDEX "IDX_2c4be03b446884f9e9c502135b" ON messaging_message USING btree ("groupId");

CREATE INDEX "IDX_2cd3b2a6b4cf0b910b260afe08" ON instance USING btree ("firstRetrievedAt");

CREATE INDEX "IDX_2cd4a2743a99671308f5417759" ON blocking USING btree ("blockeeId");

CREATE INDEX "IDX_2da24ce20ad209f1d9dc032457" ON ad USING btree ("expiresAt");

CREATE UNIQUE INDEX "IDX_2e230dd45a10e671d781d99f3e" ON channel_following USING btree ("followerId", "followeeId");

CREATE UNIQUE INDEX "IDX_307be5f1d1252e0388662acb96" ON following USING btree ("followerId", "followeeId");

CREATE UNIQUE INDEX "IDX_30bf67687f483ace115c5ca642" ON __chart__per_user_drive USING btree (date, "group");

CREATE INDEX "IDX_315c779174fe8247ab324f036e" ON drive_file USING btree ("isLink");

CREATE INDEX "IDX_318cdf42a9cfc11f479bd802bb" ON note_watching USING btree ("createdAt");

CREATE INDEX "IDX_3252a5df8d5bbd16b281f7799e" ON "user" USING btree (host);

CREATE INDEX "IDX_34415e3062ae7a94617496e81c" ON channel_muting USING btree ("userId");

CREATE UNIQUE INDEX "IDX_347fec870eafea7b26c8a73bac" ON hashtag USING btree (name);

CREATE UNIQUE INDEX "IDX_361b500e06721013c124b7b6c5" ON user_ip USING btree ("userId", ip);

CREATE UNIQUE INDEX "IDX_36cb699c49580d4e6c2e6159f9" ON __chart__federation USING btree (date);

CREATE INDEX "IDX_36ef5192a1ce55ed0e40aa4db5" ON antenna USING btree ("isActive");

CREATE INDEX "IDX_37bb9a1b4585f8a3beb24c62d6" ON drive_file USING btree (md5);

CREATE UNIQUE INDEX "IDX_39ee857ab2f23493037c6b6631" ON __chart__instance USING btree (date, "group");

CREATE INDEX "IDX_3aa8ea9a8f15214ad91638c0a7" ON flash USING btree ("updatedAt");

CREATE INDEX "IDX_3b25402709dd9882048c2bbade" ON reversi_matching USING btree ("parentId");

CREATE INDEX "IDX_3b33dff77bb64b23c88151d23e" ON drive_file USING btree ("maybeSensitive");

CREATE INDEX "IDX_3befe6f999c86aff06eb0257b4" ON user_profile USING btree ("enableWordMute");

CREATE INDEX "IDX_3ca50563facd913c425e7a89ee" ON gallery_post USING btree ("fileIds");

CREATE INDEX "IDX_3d6b372788ab01be58853003c9" ON user_group USING btree ("userId");

CREATE INDEX "IDX_3ede46f507c87ad698051d56a8" ON instance USING btree ("suspensionState");

CREATE INDEX "IDX_3f5b0899ef90527a3462d7c2cb" ON app USING btree ("userId");

CREATE UNIQUE INDEX "IDX_410cd649884b501c02d6e72738" ON user_note_pining USING btree ("userId", "noteId");

CREATE INDEX "IDX_41a3c87a37aea616ee459369e1" ON system_account USING btree ("userId");

CREATE UNIQUE INDEX "IDX_42eb716a37d381cdf566192b2b" ON __chart__notes USING btree (date);

CREATE INDEX "IDX_44499765eec6b5489d72c4253b" ON note_watching USING btree ("noteUserId");

CREATE INDEX "IDX_45145e4953780f3cd5656f0ea6" ON note_reaction USING btree ("noteId");

CREATE INDEX "IDX_47f4b1892f5d6ba8efb3057d81" ON note_favorite USING btree ("userId");

CREATE INDEX "IDX_48a00f08598662b9ca540521eb" ON user_list USING btree ("isPublic");

CREATE INDEX "IDX_4ae7053179014915d1432d3f40" ON bubble_game_record USING btree ("seededAt");

CREATE INDEX "IDX_4bb7fd4a34492ae0e6cc8d30ac" ON password_reset_request USING btree ("userId");

CREATE INDEX "IDX_4c02d38a976c3ae132228c6fce" ON hashtag USING btree ("mentionedRemoteUsersCount");

CREATE INDEX "IDX_4ccd2239268ebbd1b35e318754" ON following USING btree ("followerHost");

CREATE UNIQUE INDEX "IDX_4ce6fb9c70529b4c8ac46c9bfa" ON page_like USING btree ("userId", "pageId");

CREATE INDEX "IDX_4d534d7177fc59879d942e96d0" ON channel_muting USING btree ("channelId");

CREATE UNIQUE INDEX "IDX_4e5c4c99175638ec0761714ab0" ON user_pending USING btree (code);

CREATE INDEX "IDX_4ebbf7f93cdc10e8d1ef2fc6cd" ON abuse_user_report USING btree ("targetUserHost");

CREATE UNIQUE INDEX "IDX_4f4d35e1256c84ae3d1f0eab10" ON emoji USING btree (name, host);

CREATE UNIQUE INDEX "IDX_5048e9daccbbbc6d567bb142d3" ON __chart__per_user_notes USING btree (date, "group");

CREATE UNIQUE INDEX "IDX_50bd7164c5b78f1f4a42c4d21f" ON poll_vote USING btree ("userId", "noteId", choice);

CREATE INDEX "IDX_5108098457488634a4768e1d12" ON following USING btree (notify);

CREATE INDEX "IDX_52ccc804d7c69037d558bac4c9" ON note USING btree ("renoteId");

CREATE INDEX "IDX_530257863e1381a7f2f1d3282f" ON chat_approval USING btree ("userId");

CREATE INDEX "IDX_5377c307783fce2b6d352e1203" ON messaging_message USING btree ("userId");

CREATE INDEX "IDX_539b6c08c05067599743bb6389" ON role_assignment USING btree ("expiresAt");

CREATE INDEX "IDX_55720b33a61a7c806a8215b825" ON drive_file USING btree ("userId", "folderId", id);

CREATE INDEX "IDX_56b0166d34ddae49d8ef7610bb" ON note_unread USING btree ("userId");

CREATE INDEX "IDX_5900e907bb46516ddf2871327c" ON emoji USING btree (host);

CREATE INDEX "IDX_5a056076f76b2efe08216ba655" ON webhook USING btree (active);

CREATE INDEX "IDX_5cc8c468090e129857e9fecce5" ON user_group_invitation USING btree ("userGroupId");

CREATE UNIQUE INDEX "IDX_5deb01ae162d1d70b80d064c27" ON "user" USING btree ("usernameLower", host);

CREATE INDEX "IDX_5f265075b215fc390a57523b12" ON chat_room_invitation USING btree ("roomId");

CREATE INDEX "IDX_603a7b1e7aa0533c6c88e9bfaf" ON announcement_read USING btree ("announcementId");

CREATE INDEX "IDX_60c4af1c19a7a75f1592f93b28" ON flash_like USING btree ("userId");

CREATE UNIQUE INDEX "IDX_617a8fe225a6e701d89e02d2c7" ON __chart_day__federation USING btree (date);

CREATE UNIQUE INDEX "IDX_62aa5047b5aec92524f24c701d" ON __chart_day__per_user_drive USING btree (date, "group");

CREATE INDEX "IDX_62cb09e1129f6ec024ef66e183" ON auth_session USING btree (token);

CREATE INDEX "IDX_6446c571a0e8d0f05f01c78909" ON antenna USING btree ("userId");

CREATE INDEX "IDX_64c327441248bae40f7d92f34f" ON access_token USING btree (hash);

CREATE INDEX "IDX_650b49c5639b5840ee6a2b8f83" ON user_memo USING btree ("userId");

CREATE INDEX "IDX_6516c5a6f3c015b4eed39978be" ON following USING btree ("followerId");

CREATE INDEX "IDX_66ac4a82894297fd09ba61f3d3" ON user_memo USING btree ("targetUserId");

CREATE INDEX "IDX_66d2bd2ee31d14bcc23069a89f" ON poll_vote USING btree ("userId");

CREATE INDEX "IDX_67dc758bc0566985d1b3d39986" ON user_group_joining USING btree ("userGroupId");

CREATE INDEX "IDX_6a57f051d82c6d4036c141e107" ON note_unread USING btree ("noteChannelId");

CREATE INDEX "IDX_6d8084ec9496e7334a4602707e" ON channel_following USING btree ("followerId");

CREATE INDEX "IDX_6dd314e96806b7df65ddadff72" ON channel_muting USING btree ("expiresAt");

CREATE UNIQUE INDEX "IDX_6fc0ec357d55a18646262fdfff" ON clip_note USING btree ("noteId", "clipId");

CREATE INDEX "IDX_70ba8f6af34bc924fc9e12adb8" ON access_token USING btree (token);

CREATE INDEX "IDX_7125a826ab192eb27e11d358a5" ON note USING btree ("userHost");

CREATE INDEX "IDX_75276757070d21fdfaf4c05290" ON bubble_game_record USING btree ("userId");

CREATE INDEX "IDX_785ee5fc1ea38a1b9b38ff88e5" ON event USING btree (start);

CREATE UNIQUE INDEX "IDX_78787741f9010886796f2320a4" ON user_group_invite USING btree ("userId", "userGroupId");

CREATE INDEX "IDX_79a26e7a4d9afa5e4fc05f134e" ON chat_message USING btree ("fromUserId");

CREATE INDEX "IDX_7b8d9225168e962f94ea517e00" ON announcement USING btree (silence);

CREATE INDEX "IDX_7f7f1c66f48e9a8e18a33bc515" ON user_ip USING btree ("userId");

CREATE INDEX "IDX_7fa20a12319c7f6dc3aed98c0a" ON poll USING btree ("userHost");

CREATE INDEX "IDX_8063a0586ed1dfbe86e982d961" ON webhook USING btree ("on");

CREATE INDEX "IDX_80ca6e6ef65fb9ef34ea8c90f4" ON "user" USING btree ("updatedAt");

CREATE INDEX "IDX_8125f950afd3093acb10d2db8a" ON channel_note_pining USING btree ("channelId");

CREATE INDEX "IDX_823bae55bd81b3be6e05cff438" ON channel USING btree ("userId");

CREATE INDEX "IDX_8288151386172b8109f7239ab2" ON announcement_read USING btree ("userId");

CREATE INDEX "IDX_8302bd27226605ece14842fb25" ON channel_favorite USING btree ("userId");

CREATE INDEX "IDX_83f0862e9bae44af52ced7099e" ON promo_note USING btree ("userId");

CREATE UNIQUE INDEX "IDX_845254b3eaf708ae8a6cac3026" ON __chart__users USING btree (date);

CREATE INDEX "IDX_8552bb38e7ed038c5bdd398a38" ON chat_room_invitation USING btree ("userId");

CREATE INDEX "IDX_860fa6f6c7df5bb887249fba22" ON drive_file USING btree ("userId");

CREATE INDEX "IDX_89a29c9237b8c3b6b3cbb4cb30" ON note_unread USING btree ("isSpecified");

CREATE INDEX "IDX_8bdcd3dd2bddb78014999a16ce" ON drive_file USING btree ("maybePorn");

CREATE UNIQUE INDEX "IDX_8bfa548c2b31f9e07db113773e" ON __chart_day__network USING btree (date);

CREATE UNIQUE INDEX "IDX_8d5afc98982185799b160e10eb" ON instance USING btree (host);

CREATE UNIQUE INDEX "IDX_8f589cf056ff51f09d6096f645" ON __chart_day__hashtag USING btree (date, "group");

CREATE INDEX "IDX_8fd5215095473061855ceb948c" ON gallery_like USING btree ("userId");

CREATE INDEX "IDX_90148bbc2bf0854428786bfc15" ON page USING btree ("visibleUserIds");

CREATE UNIQUE INDEX "IDX_924fa71815cfa3941d003702a0" ON announcement_read USING btree ("userId", "announcementId");

CREATE INDEX "IDX_92779627994ac79277f070c91e" ON drive_file USING btree ("userHost");

CREATE INDEX "IDX_93060675b4a79a577f31d260c6" ON muting USING btree ("muterId");

CREATE INDEX "IDX_9657d55550c3d37bfafaf7d4b0" ON promo_read USING btree ("userId");

CREATE INDEX "IDX_97754ca6f2baff9b4abb7f853d" ON sw_subscription USING btree ("userId");

CREATE INDEX "IDX_985b836dddd8615e432d7043dd" ON gallery_post USING btree ("userId");

CREATE UNIQUE INDEX "IDX_98a1bc5cb30dfd159de056549f" ON blocking USING btree ("blockerId", "blockeeId");

CREATE INDEX "IDX_9949557d0e1b2c19e5344c171e" ON access_token USING btree ("userId");

CREATE INDEX "IDX_9b88250fc2fd009b8f1b5623ed" ON flash USING btree ("userId");

CREATE INDEX "IDX_EMOJI_CATEGORY" ON emoji USING btree (category);

CREATE INDEX "IDX_EMOJI_ROLE_IDS" ON emoji USING gin ("roleIdsThatCanBeUsedThisEmojiAsReaction");

CREATE INDEX "IDX_NOTE_DRAFT_CHANNEL_ID" ON note_draft USING btree ("channelId");

CREATE INDEX "IDX_NOTE_DRAFT_FILE_IDS" ON note_draft USING gin ("fileIds");

CREATE INDEX "IDX_NOTE_DRAFT_RENOTE_ID" ON note_draft USING btree ("renoteId");

CREATE INDEX "IDX_NOTE_DRAFT_REPLY_ID" ON note_draft USING btree ("replyId");

CREATE INDEX "IDX_NOTE_DRAFT_USER_ID" ON note_draft USING btree ("userId");

CREATE INDEX "IDX_NOTE_DRAFT_VISIBLE_USER_IDS" ON note_draft USING gin ("visibleUserIds");

CREATE INDEX "IDX_NOTE_FILE_IDS" ON note USING gin ("fileIds");

CREATE INDEX "IDX_NOTE_MENTIONS" ON note USING gin (mentions);

CREATE INDEX "IDX_NOTE_TAGS" ON note USING gin (tags);

CREATE INDEX "IDX_NOTE_VISIBLE_USER_IDS" ON note USING gin ("visibleUserIds");

CREATE INDEX "IDX_a012eaf5c87c65da1deb5fdbfa" ON clip_note USING btree ("noteId");

CREATE INDEX "IDX_a08ad074601d204e0f69da9a95" ON moderation_log USING btree ("userId");

CREATE UNIQUE INDEX "IDX_a0cd75442dd10d0643a17c4a49" ON __chart__test_unique USING btree (date, "group");

CREATE UNIQUE INDEX "IDX_a1efd3e0048a5f2793a47360dc" ON __chart__network USING btree (date);

CREATE INDEX "IDX_a27b942a0d6dcff90e3ee9b5e8" ON "user" USING btree ("usernameLower");

CREATE UNIQUE INDEX "IDX_a319e5dbf47e8a17497623beae" ON __chart__test USING btree (date, "group");

CREATE INDEX "IDX_a3eac04ae2aa9e221e7596114a" ON clip USING btree ("lastClippedAt");

CREATE INDEX "IDX_a40b8df8c989d7db937ea27cf6" ON drive_file USING btree (type);

CREATE UNIQUE INDEX "IDX_a42c93c69989ce1d09959df4cf" ON note_watching USING btree ("userId", "noteId");

CREATE INDEX "IDX_a6f649630f55af3888e5a42919" ON note USING btree ("userId", id DESC);

CREATE INDEX "IDX_a7eba67f8b3fa27271e85d2e26" ON drive_file USING btree ("isSensitive");

CREATE INDEX "IDX_a7fd92dd6dc519e6fb435dd108" ON follow_request USING btree ("followerId");

CREATE UNIQUE INDEX "IDX_a848f66d6cec11980a5dd59582" ON __chart_day__ap_request USING btree (date);

CREATE UNIQUE INDEX "IDX_a854e557b1b14814750c7c7b0c" ON "user" USING btree (token);

CREATE INDEX "IDX_a9021cc2e1feb5f72d3db6e9f5" ON abuse_user_report USING btree ("targetUserId");

CREATE INDEX "IDX_abuse_report_notification_recipient_isActive" ON abuse_report_notification_recipient USING btree ("isActive");

CREATE INDEX "IDX_abuse_report_notification_recipient_method" ON abuse_report_notification_recipient USING btree (method);

CREATE INDEX "IDX_abuse_report_notification_recipient_systemWebhookId" ON abuse_report_notification_recipient USING btree ("systemWebhookId");

CREATE INDEX "IDX_abuse_report_notification_recipient_userId" ON abuse_report_notification_recipient USING btree ("userId");

CREATE UNIQUE INDEX "IDX_ad0c221b25672daf2df320a817" ON note_reaction USING btree ("userId", "noteId");

CREATE INDEX "IDX_ae1d917992dd0c9d9bbdad06c4" ON page USING btree ("userId");

CREATE UNIQUE INDEX "IDX_ae7aab18a2641d3e5f25e0c4ea" ON note_thread_muting USING btree ("userId", "threadId");

CREATE INDEX "IDX_aecfbd5ef60374918e63ee95fa" ON poll_vote USING btree ("noteId");

CREATE INDEX "IDX_af639b066dfbca78b01a920f8a" ON page USING btree ("updatedAt");

CREATE INDEX "IDX_b0134ec406e8d09a540f818288" ON note_watching USING btree ("userId");

CREATE UNIQUE INDEX "IDX_b14489029e4b3aaf4bba5fb524" ON __chart__test_grouped USING btree (date, "group");

CREATE UNIQUE INDEX "IDX_b1754a39d0b281e07ed7c078ec" ON clip_favorite USING btree ("userId", "clipId");

CREATE INDEX "IDX_b1d46037f23d170da5c05fdf75" ON chat_approval USING btree ("otherId");

CREATE INDEX "IDX_b37dafc86e9af007e3295c2781" ON emoji USING btree (name);

CREATE INDEX "IDX_b6f93f2f30bdbb9a5ebdc7c718" ON registration_ticket USING btree ("usedById");

CREATE UNIQUE INDEX "IDX_b77d4dd9562c3a899d9a286fcd" ON __chart__per_user_following USING btree (date, "group");

CREATE INDEX "IDX_b7fcefbdd1c18dce86687531f9" ON user_list USING btree ("userId");

CREATE INDEX "IDX_b82c19c08afb292de4600d99e4" ON page USING btree (name);

CREATE INDEX "IDX_b96870ed326ccc7fa243970965" ON channel_muting USING btree ("userId", "channelId");

CREATE INDEX "IDX_bb90d1956dafc4068c28aa7560" ON drive_file USING btree ("folderId");

CREATE INDEX "IDX_bc1afcc8ef7e9400cdc3c0a87e" ON announcement USING btree ("isActive");

CREATE INDEX "IDX_be623adaa4c566baf5d29ce0c8" ON "user" USING btree (uri);

CREATE INDEX "IDX_beba993576db0261a15364ea96" ON registration_ticket USING btree ("createdById");

CREATE INDEX "IDX_bf3a053c07d9fb5d87317c56ee" ON access_token USING btree (session);

CREATE INDEX "IDX_bfbc6305547539369fe73eb144" ON user_group_invitation USING btree ("userId");

CREATE INDEX "IDX_bfbc6f79ba4007b4ce5097f08d" ON user_note_pining USING btree ("userId");

CREATE INDEX "IDX_c1240fcc9675946ea5d6c2860e" ON poll USING btree ("channelId");

CREATE INDEX "IDX_c1fd1c3dfb0627aa36c253fd14" ON muting USING btree ("expiresAt");

CREATE INDEX "IDX_c25143ebab714e930aeca1c0e8" ON chat_room_membership USING btree ("roomId");

CREATE UNIQUE INDEX "IDX_c362033aee0ea51011386a5a7e" ON system_account USING btree (type);

CREATE INDEX "IDX_c426394644267453e76f036926" ON note_thread_muting USING btree ("threadId");

CREATE UNIQUE INDEX "IDX_c5545d4b31cdc684034e33b81c" ON __chart_day__per_user_notes USING btree (date, "group");

CREATE UNIQUE INDEX "IDX_c55b2b7c284d9fef98026fc88e" ON drive_file USING btree ("webpublicAccessKey");

CREATE INDEX "IDX_c8cc87bd0f2f4487d17c651fbf" ON "user" USING btree ("lastActiveDate");

CREATE INDEX "IDX_cac14a4e3944454a5ce7daa514" ON messaging_message USING btree ("recipientId");

CREATE UNIQUE INDEX "IDX_cad6e07c20037f31cdba8a350c" ON __chart_day__users USING btree (date);

CREATE INDEX "IDX_cc7c72974f1b2f385a8921f094" ON channel USING btree ("isArchived");

CREATE INDEX "IDX_cddcaf418dc4d392ecfcca842a" ON user_list_membership USING btree ("userListId");

CREATE INDEX "IDX_ce62b50d882d4e9dee10ad0d2f" ON following USING btree ("followeeId", "followerHost", "isFollowerHibernated");

CREATE UNIQUE INDEX "IDX_cfbfeeccb0cbedcd660b17eb07" ON flash_like USING btree ("userId", "flashId");

CREATE INDEX "IDX_d3ca0db011b75ac2a940a2337d" ON channel_favorite USING btree ("channelId");

CREATE INDEX "IDX_d4ebdef929896d6dc4a3c5bb48" ON note USING btree ("threadId");

CREATE UNIQUE INDEX "IDX_d54a512b822fac7ed52800f6b4" ON follow_request USING btree ("followerId", "followeeId");

CREATE UNIQUE INDEX "IDX_d54b653660d808b118e36c184c" ON __chart_day__per_user_reaction USING btree (date, "group");

CREATE INDEX "IDX_d57f9030cd3af7f63ffb1c267c" ON hashtag USING btree ("attachedUsersCount");

CREATE UNIQUE INDEX "IDX_d5954f3df5e5e3bdfc3c03f390" ON __chart_day__active_users USING btree (date);

CREATE INDEX "IDX_d5a1b83c7cab66f167e6888188" ON "user" USING btree ("isExplorable");

CREATE UNIQUE INDEX "IDX_d6765a8c2a4c17c33f9d7f948b" ON user_list_favorite USING btree ("userId", "userListId");

CREATE UNIQUE INDEX "IDX_d85a184c2540d2deba33daf642" ON drive_file USING btree ("accessKey");

CREATE UNIQUE INDEX "IDX_d908433a4953cc13216cd9c274" ON note_unread USING btree ("userId", "noteId");

CREATE INDEX "IDX_d90c2c0e555b1eb2e4f19c9ad4" ON abuse_report_resolver USING btree ("updatedAt");

CREATE INDEX "IDX_d99c5279460fb77ef58c596ce5" ON chat_room_membership USING btree ("userId");

CREATE UNIQUE INDEX "IDX_d9ecaed8c6dc43f3592c229282" ON user_group_joining USING btree ("userId", "userGroupId");

CREATE UNIQUE INDEX "IDX_da522b4008a9f5d7743b87ad55" ON __chart__test_grouped USING btree (date) WHERE ("group" IS NULL);

CREATE INDEX "IDX_da795d3a83187e8832005ba19d" ON announcement USING btree ("forExistingUsers");

CREATE UNIQUE INDEX "IDX_dab383a36f3c9db4a0c9b02cf3" ON __chart__test USING btree (date) WHERE ("group" IS NULL);

CREATE INDEX "IDX_db5b72c16227c97ca88734d5c2" ON role_assignment USING btree ("userId");

CREATE INDEX "IDX_dce530b98e454793dac5ec2f5a" ON user_profile USING btree ("userHost");

CREATE INDEX "IDX_de22cd2b445eee31ae51cdbe99" ON user_profile USING btree (substr((birthday)::text, 6, 5));

CREATE UNIQUE INDEX "IDX_df1b5f4099e99fb0bc5eae53b6" ON gallery_like USING btree ("userId", "postId");

CREATE INDEX "IDX_e10924607d058004304611a436" ON user_group_invite USING btree ("userGroupId");

CREATE INDEX "IDX_e247b23a3c9b45f89ec1299d06" ON reversi_matching USING btree ("childId");

CREATE UNIQUE INDEX "IDX_e4849a3231f38281280ea4c0ee" ON __chart_day__per_user_following USING btree (date, "group");

CREATE UNIQUE INDEX "IDX_e4f3094c43f2d665e6030b0337" ON user_list_membership USING btree ("userId", "userListId");

CREATE UNIQUE INDEX "IDX_e56f4beac5746d44bc3e19c80d" ON __chart__ap_request USING btree (date);

CREATE INDEX "IDX_e5848eac4940934e23dbc17581" ON drive_file USING btree (uri);

CREATE INDEX "IDX_e637cba4dc4410218c4251260e" ON note_unread USING btree ("noteId");

CREATE UNIQUE INDEX "IDX_e74022ce9a074b3866f70e0d27" ON drive_file USING btree ("thumbnailAccessKey");

CREATE INDEX "IDX_e83a32a146021c72ba9bde6675" ON abuse_report_resolver USING btree ("expirationDate");

CREATE UNIQUE INDEX "IDX_e9793f65f504e5a31fbaedbf2f" ON user_group_invitation USING btree ("userId", "userGroupId");

CREATE INDEX "IDX_ebe99317bbbe9968a0c6f579ad" ON clip_note USING btree ("clipId");

CREATE INDEX "IDX_ec96b4fed9dae517e0dbbe0675" ON muting USING btree ("muteeId");

CREATE INDEX "IDX_f006b8a76efd1abf9f221c175c" ON chat_message USING btree ("toRoomId");

CREATE INDEX "IDX_f0d8ad64243fa2ca2800da0dfd" ON chat_room USING btree ("ownerId");

CREATE INDEX "IDX_f0de67fd09cd3cd0aabca79994" ON role_assignment USING btree ("roleId");

CREATE INDEX "IDX_f22169eb10657bded6d875ac8f" ON note USING btree ("channelId");

CREATE UNIQUE INDEX "IDX_f221e45cfac5bea0ce0f3149fb" ON __chart_day__per_user_pv USING btree (date, "group");

CREATE INDEX "IDX_f272c8c8805969e6a6449c77b3" ON webhook USING btree ("userId");

CREATE UNIQUE INDEX "IDX_f2a56da57921ca8439f45c1d95" ON __chart__per_user_pv USING btree (date, "group");

CREATE INDEX "IDX_f2d744d9a14d0dfb8b96cb7fc5" ON gallery_post USING btree ("isSensitive");

CREATE UNIQUE INDEX "IDX_f36fed37d6d4cdcc68c803cd9c" ON channel_note_pining USING btree ("channelId", "noteId");

CREATE INDEX "IDX_f3a1b4bd0c7cabba958a0c0b23" ON user_group_joining USING btree ("userId");

CREATE INDEX "IDX_f49922d511d666848f250663c4" ON app USING btree (secret);

CREATE INDEX "IDX_f4fc06e49c0171c85f1c48060d" ON drive_folder USING btree ("userId");

CREATE INDEX "IDX_f631d37835adb04792e361807c" ON gallery_post USING btree ("updatedAt");

CREATE INDEX "IDX_f6ba57dff679ccbcfe004698ec" ON event USING btree ("userHost");

CREATE UNIQUE INDEX "IDX_f7c3576b37bd2eec966ae24477" ON retention_aggregation USING btree ("dateKey");

CREATE INDEX "IDX_f8d8b93740ad12c4ce8213a199" ON abuse_user_report USING btree ("reporterHost");

CREATE INDEX "IDX_fa99d777623947a5b05f394cae" ON "user" USING btree (tags);

CREATE UNIQUE INDEX "IDX_faef300913c738265638ba3ebc" ON user_memo USING btree ("userId", "targetUserId");

CREATE INDEX "IDX_fb9d21ba0abb83223263df6bcb" ON registry_item USING btree ("userId");

CREATE INDEX "IDX_fcdafee716dfe9c3b5fde90f30" ON following USING btree ("followeeHost");

CREATE INDEX "IDX_fd25dfe3da37df1715f11ba6ec" ON announcement USING btree ("userId");

CREATE UNIQUE INDEX "IDX_fea7c0278325a1a2492f2d6acb" ON __chart_day__instance USING btree (date, "group");

CREATE INDEX "IDX_ff9ca3b5f3ee3d0681367a9b44" ON user_security_key USING btree ("userId");

CREATE INDEX "IDX_note_deliveryTargets" ON note USING gin ("deliveryTargets");

CREATE INDEX "IDX_note_draft_deliveryTargets" ON note_draft USING gin ("deliveryTargets");

CREATE INDEX "IDX_renote_muting_muteeId" ON muting USING btree ("muteeId");

CREATE INDEX "IDX_renote_muting_muterId" ON muting USING btree ("muterId");

CREATE INDEX "IDX_system_webhook_isActive" ON system_webhook USING btree ("isActive");

CREATE INDEX "IDX_system_webhook_on" ON system_webhook USING gin ("on");

ALTER TABLE ONLY drive_folder
    ADD CONSTRAINT "FK_00ceffb0cdc238b3233294f08f2" FOREIGN KEY ("parentId") REFERENCES drive_folder(id) ON DELETE SET NULL;

ALTER TABLE ONLY user_list_favorite
    ADD CONSTRAINT "FK_016f613dc4feb807e03e3e7da92" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_list_membership
    ADD CONSTRAINT "FK_021015e6683570ae9f6b0c62bee" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_watching
    ADD CONSTRAINT "FK_03e7028ab8388a3f5e3ce2a8619" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY abuse_user_report
    ADD CONSTRAINT "FK_04cc96756f89d0b7f9473e8cdf3" FOREIGN KEY ("reporterId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY blocking
    ADD CONSTRAINT "FK_0627125f1a8a42c9a1929edb552" FOREIGN KEY ("blockerId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY abuse_user_report
    ADD CONSTRAINT "FK_08b883dd5fdd6f9c4c1572b36de" FOREIGN KEY ("assigneeId") REFERENCES "user"(id) ON DELETE SET NULL;

ALTER TABLE ONLY note_favorite
    ADD CONSTRAINT "FK_0e00498f180193423c992bc4370" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_following
    ADD CONSTRAINT "FK_0e43068c3f92cab197c3d3cd86e" FOREIGN KEY ("followeeId") REFERENCES channel(id) ON DELETE CASCADE;

ALTER TABLE ONLY page_like
    ADD CONSTRAINT "FK_0e61efab7f88dbb79c9166dbb48" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_invite
    ADD CONSTRAINT "FK_1039988afa3bf991185b277fe03" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_note_pining
    ADD CONSTRAINT "FK_10b19ef67d297ea9de325cd4502" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_publickey
    ADD CONSTRAINT "FK_10c146e4b39b443ede016f6736d" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY follow_request
    ADD CONSTRAINT "FK_12c01c0d1a79f77d9f6c15fadd2" FOREIGN KEY ("followeeId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_reaction
    ADD CONSTRAINT "FK_13761f64257f40c5636d0ff95ee" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_history
    ADD CONSTRAINT "FK_1e2492ba7582bf830b750a29627" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY following
    ADD CONSTRAINT "FK_24e0042143a18157b234df186c3" FOREIGN KEY ("followeeId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY clip_favorite
    ADD CONSTRAINT "FK_25a31662b0b0cc9af6549a9d711" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_message
    ADD CONSTRAINT "FK_25e097b51d7622c249452c6f757" FOREIGN KEY ("toUserId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_thread_muting
    ADD CONSTRAINT "FK_29c11c7deb06615076f8c95b80a" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY event
    ADD CONSTRAINT "FK_2b481f231cd035e84390072bf7b" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY clip
    ADD CONSTRAINT "FK_2b5ec6c574d6802c94c80313fb2" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY signin
    ADD CONSTRAINT "FK_2c308dbdc50d94dc625670055f7" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY messaging_message
    ADD CONSTRAINT "FK_2c4be03b446884f9e9c502135be" FOREIGN KEY ("groupId") REFERENCES user_group(id) ON DELETE CASCADE;

ALTER TABLE ONLY blocking
    ADD CONSTRAINT "FK_2cd4a2743a99671308f5417759e" FOREIGN KEY ("blockeeId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_muting
    ADD CONSTRAINT "FK_34415e3062ae7a94617496e81c5" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY reversi_matching
    ADD CONSTRAINT "FK_3b25402709dd9882048c2bbade0" FOREIGN KEY ("parentId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group
    ADD CONSTRAINT "FK_3d6b372788ab01be58853003c93" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY app
    ADD CONSTRAINT "FK_3f5b0899ef90527a3462d7c2cb3" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE SET NULL;

ALTER TABLE ONLY system_account
    ADD CONSTRAINT "FK_41a3c87a37aea616ee459369e12" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_reaction
    ADD CONSTRAINT "FK_45145e4953780f3cd5656f0ea6a" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_favorite
    ADD CONSTRAINT "FK_47f4b1892f5d6ba8efb3057d81a" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY password_reset_request
    ADD CONSTRAINT "FK_4bb7fd4a34492ae0e6cc8d30ac8" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_list_favorite
    ADD CONSTRAINT "FK_4d52b20bfe32c8552e7a61e80d2" FOREIGN KEY ("userListId") REFERENCES user_list(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_muting
    ADD CONSTRAINT "FK_4d534d7177fc59879d942e96d03" FOREIGN KEY ("channelId") REFERENCES channel(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT "FK_51cb79b5555effaf7d69ba1cff9" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_approval
    ADD CONSTRAINT "FK_530257863e1381a7f2f1d3282fe" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY messaging_message
    ADD CONSTRAINT "FK_535def119223ac05ad3fa9ef64b" FOREIGN KEY ("fileId") REFERENCES drive_file(id) ON DELETE CASCADE;

ALTER TABLE ONLY messaging_message
    ADD CONSTRAINT "FK_5377c307783fce2b6d352e1203b" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_unread
    ADD CONSTRAINT "FK_56b0166d34ddae49d8ef7610bb9" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "FK_58f5c71eaab331645112cf8cfa5" FOREIGN KEY ("avatarId") REFERENCES drive_file(id) ON DELETE SET NULL;

ALTER TABLE ONLY note
    ADD CONSTRAINT "FK_5b87d9d19127bd5d92026017a7b" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_invitation
    ADD CONSTRAINT "FK_5cc8c468090e129857e9fecce5a" FOREIGN KEY ("userGroupId") REFERENCES user_group(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_room_invitation
    ADD CONSTRAINT "FK_5f265075b215fc390a57523b12a" FOREIGN KEY ("roomId") REFERENCES chat_room(id) ON DELETE CASCADE;

ALTER TABLE ONLY announcement_read
    ADD CONSTRAINT "FK_603a7b1e7aa0533c6c88e9bfafe" FOREIGN KEY ("announcementId") REFERENCES announcement(id) ON DELETE CASCADE;

ALTER TABLE ONLY flash_like
    ADD CONSTRAINT "FK_60c4af1c19a7a75f1592f93b287" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY antenna
    ADD CONSTRAINT "FK_6446c571a0e8d0f05f01c789096" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_memo
    ADD CONSTRAINT "FK_650b49c5639b5840ee6a2b8f83e" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY following
    ADD CONSTRAINT "FK_6516c5a6f3c015b4eed39978be5" FOREIGN KEY ("followerId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY reversi_game
    ADD CONSTRAINT "FK_6649a4e8c5d5cf32fb03b5da9f6" FOREIGN KEY ("user2Id") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_memo
    ADD CONSTRAINT "FK_66ac4a82894297fd09ba61f3d35" FOREIGN KEY ("targetUserId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY poll_vote
    ADD CONSTRAINT "FK_66d2bd2ee31d14bcc23069a89f8" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_joining
    ADD CONSTRAINT "FK_67dc758bc0566985d1b3d399865" FOREIGN KEY ("userGroupId") REFERENCES user_group(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_note_pining
    ADD CONSTRAINT "FK_68881008f7c3588ad7ecae471cf" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY flash_like
    ADD CONSTRAINT "FK_6c16fe0e93b7a1951eca624b76a" FOREIGN KEY ("flashId") REFERENCES flash(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_following
    ADD CONSTRAINT "FK_6d8084ec9496e7334a4602707e1" FOREIGN KEY ("followerId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT "FK_6dc44f1ceb65b1e72bacef2ca27" FOREIGN KEY ("pinnedPageId") REFERENCES page(id) ON DELETE SET NULL;

ALTER TABLE ONLY antenna
    ADD CONSTRAINT "FK_709d7d32053d0dd7620f678eeb9" FOREIGN KEY ("userListId") REFERENCES user_list(id) ON DELETE CASCADE;

ALTER TABLE ONLY bubble_game_record
    ADD CONSTRAINT "FK_75276757070d21fdfaf4c052909" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_message
    ADD CONSTRAINT "FK_79a26e7a4d9afa5e4fc05f134ed" FOREIGN KEY ("fromUserId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_note_pining
    ADD CONSTRAINT "FK_8125f950afd3093acb10d2db8a8" FOREIGN KEY ("channelId") REFERENCES channel(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel
    ADD CONSTRAINT "FK_823bae55bd81b3be6e05cff4383" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE SET NULL;

ALTER TABLE ONLY announcement_read
    ADD CONSTRAINT "FK_8288151386172b8109f7239ab28" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_favorite
    ADD CONSTRAINT "FK_8302bd27226605ece14842fb25a" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_room_invitation
    ADD CONSTRAINT "FK_8552bb38e7ed038c5bdd398a384" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY drive_file
    ADD CONSTRAINT "FK_860fa6f6c7df5bb887249fba22e" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE SET NULL;

ALTER TABLE ONLY gallery_like
    ADD CONSTRAINT "FK_8fd5215095473061855ceb948cf" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY muting
    ADD CONSTRAINT "FK_93060675b4a79a577f31d260c67" FOREIGN KEY ("muterId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_history
    ADD CONSTRAINT "FK_95a9f7f6939a5cd4ec5d84979af" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY promo_read
    ADD CONSTRAINT "FK_9657d55550c3d37bfafaf7d4b05" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY sw_subscription
    ADD CONSTRAINT "FK_97754ca6f2baff9b4abb7f853dd" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY gallery_post
    ADD CONSTRAINT "FK_985b836dddd8615e432d7043ddb" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY access_token
    ADD CONSTRAINT "FK_9949557d0e1b2c19e5344c171e9" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel
    ADD CONSTRAINT "FK_999da2bcc7efadbfe0e92d3bc19" FOREIGN KEY ("bannerId") REFERENCES drive_file(id) ON DELETE SET NULL;

ALTER TABLE ONLY flash
    ADD CONSTRAINT "FK_9b88250fc2fd009b8f1b5623ed5" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY clip_note
    ADD CONSTRAINT "FK_a012eaf5c87c65da1deb5fdbfa3" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY moderation_log
    ADD CONSTRAINT "FK_a08ad074601d204e0f69da9a954" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY access_token
    ADD CONSTRAINT "FK_a3ff16c90cc87a82a0b5959e560" FOREIGN KEY ("appId") REFERENCES app(id) ON DELETE CASCADE;

ALTER TABLE ONLY promo_read
    ADD CONSTRAINT "FK_a46a1a603ecee695d7db26da5f4" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY follow_request
    ADD CONSTRAINT "FK_a7fd92dd6dc519e6fb435dd108f" FOREIGN KEY ("followerId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY abuse_user_report
    ADD CONSTRAINT "FK_a9021cc2e1feb5f72d3db6e9f5f" FOREIGN KEY ("targetUserId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY page
    ADD CONSTRAINT "FK_a9ca79ad939bf06066b81c9d3aa" FOREIGN KEY ("eyeCatchingImageId") REFERENCES drive_file(id) ON DELETE SET NULL;

ALTER TABLE ONLY abuse_report_notification_recipient
    ADD CONSTRAINT "FK_abuse_report_notification_recipient_systemWebhookId" FOREIGN KEY ("systemWebhookId") REFERENCES system_webhook(id) ON DELETE CASCADE;

ALTER TABLE ONLY abuse_report_notification_recipient
    ADD CONSTRAINT "FK_abuse_report_notification_recipient_userId1" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY abuse_report_notification_recipient
    ADD CONSTRAINT "FK_abuse_report_notification_recipient_userId2" FOREIGN KEY ("userId") REFERENCES user_profile("userId") ON DELETE CASCADE;

ALTER TABLE ONLY page
    ADD CONSTRAINT "FK_ae1d917992dd0c9d9bbdad06c4a" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY poll_vote
    ADD CONSTRAINT "FK_aecfbd5ef60374918e63ee95fa7" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY "user"
    ADD CONSTRAINT "FK_afc64b53f8db3707ceb34eb28e2" FOREIGN KEY ("bannerId") REFERENCES drive_file(id) ON DELETE SET NULL;

ALTER TABLE ONLY note_watching
    ADD CONSTRAINT "FK_b0134ec406e8d09a540f8182888" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY gallery_like
    ADD CONSTRAINT "FK_b1cb568bfe569e47b7051699fc8" FOREIGN KEY ("postId") REFERENCES gallery_post(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_approval
    ADD CONSTRAINT "FK_b1d46037f23d170da5c05fdf755" FOREIGN KEY ("otherId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY registration_ticket
    ADD CONSTRAINT "FK_b6f93f2f30bdbb9a5ebdc7c7189" FOREIGN KEY ("usedById") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_list
    ADD CONSTRAINT "FK_b7fcefbdd1c18dce86687531f99" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY drive_file
    ADD CONSTRAINT "FK_bb90d1956dafc4068c28aa7560a" FOREIGN KEY ("folderId") REFERENCES drive_folder(id) ON DELETE SET NULL;

ALTER TABLE ONLY registration_ticket
    ADD CONSTRAINT "FK_beba993576db0261a15364ea96e" FOREIGN KEY ("createdById") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_invitation
    ADD CONSTRAINT "FK_bfbc6305547539369fe73eb144a" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_note_pining
    ADD CONSTRAINT "FK_bfbc6f79ba4007b4ce5097f08d6" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY auth_session
    ADD CONSTRAINT "FK_c072b729d71697f959bde66ade0" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_room_membership
    ADD CONSTRAINT "FK_c25143ebab714e930aeca1c0e8d" FOREIGN KEY ("roomId") REFERENCES chat_room(id) ON DELETE CASCADE;

ALTER TABLE ONLY meta
    ADD CONSTRAINT "FK_c80e4079d632f95eac06a9d28cc" FOREIGN KEY ("rootUserId") REFERENCES "user"(id) ON DELETE SET NULL;

ALTER TABLE ONLY messaging_message
    ADD CONSTRAINT "FK_cac14a4e3944454a5ce7daa5142" FOREIGN KEY ("recipientId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY antenna
    ADD CONSTRAINT "FK_ccbf5a8c0be4511133dcc50ddeb" FOREIGN KEY ("userGroupJoiningId") REFERENCES user_group_joining(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_list_membership
    ADD CONSTRAINT "FK_cddcaf418dc4d392ecfcca842a7" FOREIGN KEY ("userListId") REFERENCES user_list(id) ON DELETE CASCADE;

ALTER TABLE ONLY page_like
    ADD CONSTRAINT "FK_cf8782626dced3176038176a847" FOREIGN KEY ("pageId") REFERENCES page(id) ON DELETE CASCADE;

ALTER TABLE ONLY channel_favorite
    ADD CONSTRAINT "FK_d3ca0db011b75ac2a940a2337d2" FOREIGN KEY ("channelId") REFERENCES channel(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_room_membership
    ADD CONSTRAINT "FK_d99c5279460fb77ef58c596ce51" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY poll
    ADD CONSTRAINT "FK_da851e06d0dfe2ef397d8b1bf1b" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY role_assignment
    ADD CONSTRAINT "FK_db5b72c16227c97ca88734d5c2b" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY auth_session
    ADD CONSTRAINT "FK_dbe037d4bddd17b03a1dc778dee" FOREIGN KEY ("appId") REFERENCES app(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_invite
    ADD CONSTRAINT "FK_e10924607d058004304611a436a" FOREIGN KEY ("userGroupId") REFERENCES user_group(id) ON DELETE CASCADE;

ALTER TABLE ONLY reversi_matching
    ADD CONSTRAINT "FK_e247b23a3c9b45f89ec1299d066" FOREIGN KEY ("childId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY promo_note
    ADD CONSTRAINT "FK_e263909ca4fe5d57f8d4230dd5c" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_draft
    ADD CONSTRAINT "FK_e4983f28b4b18b03491536052f5" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY note_unread
    ADD CONSTRAINT "FK_e637cba4dc4410218c4251260e4" FOREIGN KEY ("noteId") REFERENCES note(id) ON DELETE CASCADE;

ALTER TABLE ONLY clip_note
    ADD CONSTRAINT "FK_ebe99317bbbe9968a0c6f579adf" FOREIGN KEY ("clipId") REFERENCES clip(id) ON DELETE CASCADE;

ALTER TABLE ONLY muting
    ADD CONSTRAINT "FK_ec96b4fed9dae517e0dbbe0675c" FOREIGN KEY ("muteeId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_message
    ADD CONSTRAINT "FK_f006b8a76efd1abf9f221c175ce" FOREIGN KEY ("toRoomId") REFERENCES chat_room(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_room
    ADD CONSTRAINT "FK_f0d8ad64243fa2ca2800da0dfd6" FOREIGN KEY ("ownerId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY role_assignment
    ADD CONSTRAINT "FK_f0de67fd09cd3cd0aabca79994d" FOREIGN KEY ("roleId") REFERENCES role(id) ON DELETE CASCADE;

ALTER TABLE ONLY note
    ADD CONSTRAINT "FK_f22169eb10657bded6d875ac8f9" FOREIGN KEY ("channelId") REFERENCES channel(id) ON DELETE CASCADE;

ALTER TABLE ONLY webhook
    ADD CONSTRAINT "FK_f272c8c8805969e6a6449c77b3c" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_group_joining
    ADD CONSTRAINT "FK_f3a1b4bd0c7cabba958a0c0b231" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_keypair
    ADD CONSTRAINT "FK_f4853eb41ab722fe05f81cedeb6" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY drive_folder
    ADD CONSTRAINT "FK_f4fc06e49c0171c85f1c48060d2" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY reversi_game
    ADD CONSTRAINT "FK_f7467510c60a45ce5aca6292743" FOREIGN KEY ("user1Id") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY registry_item
    ADD CONSTRAINT "FK_fb9d21ba0abb83223263df6bcb3" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY clip_favorite
    ADD CONSTRAINT "FK_fce61c7986cee54393e79f1d849" FOREIGN KEY ("clipId") REFERENCES clip(id) ON DELETE CASCADE;

ALTER TABLE ONLY chat_message
    ADD CONSTRAINT "FK_fd0f9a4879430239715ad4f8e2a" FOREIGN KEY ("fileId") REFERENCES drive_file(id) ON DELETE SET NULL;

ALTER TABLE ONLY announcement
    ADD CONSTRAINT "FK_fd25dfe3da37df1715f11ba6ec8" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY user_security_key
    ADD CONSTRAINT "FK_ff9ca3b5f3ee3d0681367a9b447" FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE;

ALTER TABLE ONLY poll_vote
    ADD CONSTRAINT "FK_poll_vote_poll" FOREIGN KEY ("noteId") REFERENCES poll("noteId") ON DELETE CASCADE;

INSERT INTO migrations VALUES (1, 1000000000000, 'Init1000000000000');
INSERT INTO migrations VALUES (2, 1556348509290, 'Pages1556348509290');
INSERT INTO migrations VALUES (3, 1556746559567, 'UserProfile1556746559567');
INSERT INTO migrations VALUES (4, 1557476068003, 'PinnedUsers1557476068003');
INSERT INTO migrations VALUES (5, 1557761316509, 'AddSomeUrls1557761316509');
INSERT INTO migrations VALUES (6, 1557932705754, 'ObjectStorageSetting1557932705754');
INSERT INTO migrations VALUES (7, 1558072954435, 'PageLike1558072954435');
INSERT INTO migrations VALUES (8, 1558103093633, 'UserGroup1558103093633');
INSERT INTO migrations VALUES (9, 1558257926829, 'UserGroupInvite1558257926829');
INSERT INTO migrations VALUES (10, 1558266512381, 'UserListJoining1558266512381');
INSERT INTO migrations VALUES (11, 1561706992953, 'webauthn1561706992953');
INSERT INTO migrations VALUES (12, 1561873850023, 'ChartIndexes1561873850023');
INSERT INTO migrations VALUES (13, 1562422242907, 'PasswordLessLogin1562422242907');
INSERT INTO migrations VALUES (14, 1562444565093, 'PinnedPage1562444565093');
INSERT INTO migrations VALUES (15, 1562448332510, 'PageTitleHideOption1562448332510');
INSERT INTO migrations VALUES (16, 1562869971568, 'ModerationLog1562869971568');
INSERT INTO migrations VALUES (17, 1563757595828, 'UsedUsername1563757595828');
INSERT INTO migrations VALUES (18, 1565634203341, 'room1565634203341');
INSERT INTO migrations VALUES (19, 1571220798684, 'CustomEmojiCategory1571220798684');
INSERT INTO migrations VALUES (20, 1572760203493, 'nodeinfo1572760203493');
INSERT INTO migrations VALUES (21, 1576269851876, 'TalkFederationId1576269851876');
INSERT INTO migrations VALUES (22, 1576869585998, 'ProxyRemoteFiles1576869585998');
INSERT INTO migrations VALUES (23, 1579267006611, 'v121579267006611');
INSERT INTO migrations VALUES (24, 1579270193251, 'v1221579270193251');
INSERT INTO migrations VALUES (25, 1579282808087, 'v1231579282808087');
INSERT INTO migrations VALUES (26, 1579544426412, 'v1241579544426412');
INSERT INTO migrations VALUES (27, 1579977526288, 'v1251579977526288');
INSERT INTO migrations VALUES (28, 1579993013959, 'v1261579993013959');
INSERT INTO migrations VALUES (29, 1580069531114, 'v1271580069531114');
INSERT INTO migrations VALUES (30, 1580148575182, 'v1281580148575182');
INSERT INTO migrations VALUES (31, 1580154400017, 'v1291580154400017');
INSERT INTO migrations VALUES (32, 1580276619901, 'v12101580276619901');
INSERT INTO migrations VALUES (33, 1580331224276, 'v12111580331224276');
INSERT INTO migrations VALUES (34, 1580508795118, 'v12121580508795118');
INSERT INTO migrations VALUES (35, 1580543501339, 'v12131580543501339');
INSERT INTO migrations VALUES (36, 1580864313253, 'v12141580864313253');
INSERT INTO migrations VALUES (37, 1581526429287, 'userGroupInvitation1581526429287');
INSERT INTO migrations VALUES (38, 1581695816408, 'userGroupAntenna1581695816408');
INSERT INTO migrations VALUES (39, 1581708415836, 'driveUserFolderIdIndex1581708415836');
INSERT INTO migrations VALUES (40, 1581979837262, 'promo1581979837262');
INSERT INTO migrations VALUES (41, 1582019042083, 'featuredInjecttion1582019042083');
INSERT INTO migrations VALUES (42, 1582210532752, 'antennaExclude1582210532752');
INSERT INTO migrations VALUES (43, 1582875306439, 'noteReactionLength1582875306439');
INSERT INTO migrations VALUES (44, 1585361548360, 'miauth1585361548360');
INSERT INTO migrations VALUES (45, 1585385921215, 'customNotification1585385921215');
INSERT INTO migrations VALUES (46, 1585772678853, 'apUrl1585772678853');
INSERT INTO migrations VALUES (47, 1586624197029, 'AddObjectStorageUseProxy1586624197029');
INSERT INTO migrations VALUES (48, 1586641139527, 'remoteReaction1586641139527');
INSERT INTO migrations VALUES (49, 1586708940386, 'pageAiScript1586708940386');
INSERT INTO migrations VALUES (50, 1588044505511, 'hCaptcha1588044505511');
INSERT INTO migrations VALUES (51, 1589023282116, 'pubRelay1589023282116');
INSERT INTO migrations VALUES (52, 1595075960584, 'blurhash1595075960584');
INSERT INTO migrations VALUES (53, 1595077605646, 'blurhashForAvatarBanner1595077605646');
INSERT INTO migrations VALUES (54, 1595676934834, 'instanceIconUrl1595676934834');
INSERT INTO migrations VALUES (55, 1595771249699, 'wordMute1595771249699');
INSERT INTO migrations VALUES (56, 1595782306083, 'wordMute21595782306083');
INSERT INTO migrations VALUES (57, 1596548170836, 'channel1596548170836');
INSERT INTO migrations VALUES (58, 1596786425167, 'channel21596786425167');
INSERT INTO migrations VALUES (59, 1597230137744, 'objectStorageSetPublicRead1597230137744');
INSERT INTO migrations VALUES (60, 1597236229720, 'IncludingNotificationTypes1597236229720');
INSERT INTO migrations VALUES (61, 1597385880794, 'addSensitiveIndex1597385880794');
INSERT INTO migrations VALUES (62, 1597459042300, 'channelUnread1597459042300');
INSERT INTO migrations VALUES (63, 1597893996136, 'ChannelNoteIdDescIndex1597893996136');
INSERT INTO migrations VALUES (64, 1600353287890, 'mutingNotificationTypes1600353287890');
INSERT INTO migrations VALUES (65, 1603094348345, 'refineAbuseUserReport1603094348345');
INSERT INTO migrations VALUES (66, 1603095701770, 'refineAbuseUserReport21603095701770');
INSERT INTO migrations VALUES (67, 1603776877564, 'instanceThemeColor1603776877564');
INSERT INTO migrations VALUES (68, 1603781553011, 'instanceFavicon1603781553011');
INSERT INTO migrations VALUES (69, 1604821689616, 'deleteAutoWatch1604821689616');
INSERT INTO migrations VALUES (70, 1605408848373, 'clipDescription1605408848373');
INSERT INTO migrations VALUES (71, 1605408971051, 'comments1605408971051');
INSERT INTO migrations VALUES (72, 1605585339718, 'instancePinnedPages1605585339718');
INSERT INTO migrations VALUES (73, 1605965516823, 'instanceImages1605965516823');
INSERT INTO migrations VALUES (74, 1606191203881, 'noCrawle1606191203881');
INSERT INTO migrations VALUES (75, 1607151207216, 'instancePinnedClip1607151207216');
INSERT INTO migrations VALUES (76, 1607353487793, 'isExplorable1607353487793');
INSERT INTO migrations VALUES (77, 1610277136869, 'registry1610277136869');
INSERT INTO migrations VALUES (78, 1610277585759, 'registry21610277585759');
INSERT INTO migrations VALUES (79, 1610283021566, 'registry31610283021566');
INSERT INTO migrations VALUES (80, 1611354329133, 'followersUri1611354329133');
INSERT INTO migrations VALUES (81, 1611397665007, 'gallery1611397665007');
INSERT INTO migrations VALUES (82, 1611547387175, 'objectStorageS3ForcePathStyle1611547387175');
INSERT INTO migrations VALUES (83, 1612619156584, 'announcementEmail1612619156584');
INSERT INTO migrations VALUES (84, 1613155914446, 'emailNotificationTypes1613155914446');
INSERT INTO migrations VALUES (85, 1613181457597, 'userLang1613181457597');
INSERT INTO migrations VALUES (86, 1613503367223, 'useBigintForDriveUsage1613503367223');
INSERT INTO migrations VALUES (87, 1615965918224, 'chartV21615965918224');
INSERT INTO migrations VALUES (88, 1615966519402, 'chartV221615966519402');
INSERT INTO migrations VALUES (89, 1618637372000, 'userLastActiveDate1618637372000');
INSERT INTO migrations VALUES (90, 1618639857000, 'userHideOnlineStatus1618639857000');
INSERT INTO migrations VALUES (91, 1619942102890, 'passwordReset1619942102890');
INSERT INTO migrations VALUES (92, 1620019354680, 'ad1620019354680');
INSERT INTO migrations VALUES (93, 1620364649428, 'ad21620364649428');
INSERT INTO migrations VALUES (94, 1621479946000, 'addNoteIndexes1621479946000');
INSERT INTO migrations VALUES (95, 1622679304522, 'userProfileDescriptionLength1622679304522');
INSERT INTO migrations VALUES (96, 1622681548499, 'logMessageLength1622681548499');
INSERT INTO migrations VALUES (97, 1626509500668, 'fixRemoteFileProxy1626509500668');
INSERT INTO migrations VALUES (98, 1629004542760, 'chartReindex1629004542760');
INSERT INTO migrations VALUES (99, 1629024377804, 'deeplIntegration1629024377804');
INSERT INTO migrations VALUES (100, 1629288472000, 'fixChannelUserId1629288472000');
INSERT INTO migrations VALUES (101, 1629387925000, 'disableRightClick1629387925000');
INSERT INTO migrations VALUES (102, 1629512953000, 'isUserDeleted1629512953000');
INSERT INTO migrations VALUES (103, 1629778475000, 'deeplIntegration21629778475000');
INSERT INTO migrations VALUES (104, 1629833361000, 'addShowTLReplies1629833361000');
INSERT INTO migrations VALUES (105, 1629968054000, 'userInstanceBlocks1629968054000');
INSERT INTO migrations VALUES (106, 1633068642000, 'emailRequiredForSignup1633068642000');
INSERT INTO migrations VALUES (107, 1633071909016, 'userPending1633071909016');
INSERT INTO migrations VALUES (108, 1634486652000, 'userPublicReactions1634486652000');
INSERT INTO migrations VALUES (109, 1634902659689, 'deleteLog1634902659689');
INSERT INTO migrations VALUES (110, 1635500777168, 'noteThreadMute1635500777168');
INSERT INTO migrations VALUES (111, 1636197624383, 'ffVisibility1636197624383');
INSERT INTO migrations VALUES (112, 1636697408073, 'removeViaMobile1636697408073');
INSERT INTO migrations VALUES (113, 1637320813000, 'forwardedReport1637320813000');
INSERT INTO migrations VALUES (114, 1639325650583, 'chartV31639325650583');
INSERT INTO migrations VALUES (115, 1642611822809, 'emojiUrl1642611822809');
INSERT INTO migrations VALUES (116, 1642613870898, 'driveFileWebpublicType1642613870898');
INSERT INTO migrations VALUES (117, 1643963705770, 'chartV41643963705770');
INSERT INTO migrations VALUES (118, 1643966656277, 'chartV51643966656277');
INSERT INTO migrations VALUES (119, 1643967331284, 'chartV61643967331284');
INSERT INTO migrations VALUES (120, 1644010796173, 'convertHardMutes1644010796173');
INSERT INTO migrations VALUES (121, 1644058404077, 'chartV71644058404077');
INSERT INTO migrations VALUES (122, 1644059847460, 'chartV81644059847460');
INSERT INTO migrations VALUES (123, 1644060125705, 'chartV91644060125705');
INSERT INTO migrations VALUES (124, 1644073149413, 'chartV101644073149413');
INSERT INTO migrations VALUES (125, 1644095659741, 'chartV111644095659741');
INSERT INTO migrations VALUES (126, 1644328606241, 'chartV121644328606241');
INSERT INTO migrations VALUES (127, 1644331238153, 'chartV131644331238153');
INSERT INTO migrations VALUES (128, 1644344266289, 'chartV141644344266289');
INSERT INTO migrations VALUES (129, 1644395759931, 'instanceThemeColor1644395759931');
INSERT INTO migrations VALUES (130, 1644481657998, 'chartV151644481657998');
INSERT INTO migrations VALUES (131, 1644551208096, 'followingIndexes1644551208096');
INSERT INTO migrations VALUES (132, 1645340161439, 'removeMaxNoteTextLength1645340161439');
INSERT INTO migrations VALUES (133, 1645599900873, 'federationChartPubsub1645599900873');
INSERT INTO migrations VALUES (134, 1646143552768, 'instanceDefaultTheme1646143552768');
INSERT INTO migrations VALUES (135, 1646387162108, 'muteExpiresAt1646387162108');
INSERT INTO migrations VALUES (136, 1646549089451, 'pollEndedNotification1646549089451');
INSERT INTO migrations VALUES (137, 1646633030285, 'chartFederationActive1646633030285');
INSERT INTO migrations VALUES (138, 1646655454495, 'removeInstanceDriveColumns1646655454495');
INSERT INTO migrations VALUES (139, 1646732390560, 'chartFederationActiveSubPub1646732390560');
INSERT INTO migrations VALUES (140, 1648548247382, 'webhook1648548247382');
INSERT INTO migrations VALUES (141, 1648816172177, 'webhook21648816172177');
INSERT INTO migrations VALUES (142, 1651224615271, 'foreignKeyReports1651224615271');
INSERT INTO migrations VALUES (143, 1652859567549, 'uniformThemecolor1652859567549');
INSERT INTO migrations VALUES (144, 1654589815249, 'increaseSmtpCharLimit1654589815249');
INSERT INTO migrations VALUES (145, 1655368940105, 'nsfwDetection1655368940105');
INSERT INTO migrations VALUES (146, 1655371960534, 'nsfwDetection21655371960534');
INSERT INTO migrations VALUES (147, 1655388169582, 'nsfwDetection31655388169582');
INSERT INTO migrations VALUES (148, 1655393015659, 'nsfwDetection41655393015659');
INSERT INTO migrations VALUES (149, 1655813815729, 'driveCapacityOverrideMb1655813815729');
INSERT INTO migrations VALUES (150, 1655918165614, 'userIp1655918165614');
INSERT INTO migrations VALUES (151, 1656122560740, 'fileIp1656122560740');
INSERT INTO migrations VALUES (152, 1656251734807, 'nsfwDetection51656251734807');
INSERT INTO migrations VALUES (153, 1656328812281, 'ip21656328812281');
INSERT INTO migrations VALUES (154, 1656408772602, 'nsfwDetection61656408772602');
INSERT INTO migrations VALUES (155, 1656772790599, 'userModerationNote1656772790599');
INSERT INTO migrations VALUES (156, 1657346559800, 'activeEmailValidation1657346559800');
INSERT INTO migrations VALUES (157, 1660183643857, 'multipleTranslationServices1660183643857');
INSERT INTO migrations VALUES (158, 1664694635394, 'turnstile1664694635394');
INSERT INTO migrations VALUES (159, 1665091090561, 'addRenoteMuting1665091090561');
INSERT INTO migrations VALUES (160, 1669138716634, 'whetherPushNotifyToSendReadMessage1669138716634');
INSERT INTO migrations VALUES (161, 1671924750884, 'RetentionAggregation1671924750884');
INSERT INTO migrations VALUES (162, 1671926422832, 'RetentionAggregation21671926422832');
INSERT INTO migrations VALUES (163, 1672562400597, 'PerUserPvChart1672562400597');
INSERT INTO migrations VALUES (164, 1672703171386, 'removeLatestRequestSentAt1672703171386');
INSERT INTO migrations VALUES (165, 1672704017999, 'removeLastCommunicatedAt1672704017999');
INSERT INTO migrations VALUES (166, 1672704136584, 'removeLatestStatus1672704136584');
INSERT INTO migrations VALUES (167, 1672822262496, 'Flash1672822262496');
INSERT INTO migrations VALUES (168, 1673336077243, 'PollChoiceLength1673336077243');
INSERT INTO migrations VALUES (169, 1673500412259, 'Role1673500412259');
INSERT INTO migrations VALUES (170, 1673515526953, 'RoleColor1673515526953');
INSERT INTO migrations VALUES (171, 1673522856499, 'RoleIroiro1673522856499');
INSERT INTO migrations VALUES (172, 1673524604156, 'RoleLastUsedAt1673524604156');
INSERT INTO migrations VALUES (173, 1673570377815, 'RoleConditional1673570377815');
INSERT INTO migrations VALUES (174, 1673575973645, 'MetaClean1673575973645');
INSERT INTO migrations VALUES (175, 1673783015567, 'Policies1673783015567');
INSERT INTO migrations VALUES (176, 1673812883772, 'firstRetrievedAt1673812883772');
INSERT INTO migrations VALUES (177, 1674086433654, 'flashScriptLength1674086433654');
INSERT INTO migrations VALUES (178, 1674118260469, 'achievement1674118260469');
INSERT INTO migrations VALUES (179, 1674255666603, 'loggedInDates1674255666603');
INSERT INTO migrations VALUES (180, 1675053125067, 'fixforeignkeyreports1675053125067');
INSERT INTO migrations VALUES (181, 1675404035646, 'cleanup1675404035646');
INSERT INTO migrations VALUES (182, 1675557528704, 'roleIconBadge1675557528704');
INSERT INTO migrations VALUES (183, 1676438468213, 'ad1676438468213');
INSERT INTO migrations VALUES (184, 1677054292210, 'ad1677054292210');
INSERT INTO migrations VALUES (185, 1677570181236, 'roleAssignmentExpiresAt1677570181236');
INSERT INTO migrations VALUES (186, 1678164627293, 'perNoteReactionAcceptance1678164627293');
INSERT INTO migrations VALUES (187, 1678426061773, 'tweakVarcharLength1678426061773');
INSERT INTO migrations VALUES (188, 1678427401214, 'removeUnused1678427401214');
INSERT INTO migrations VALUES (189, 1678602320354, 'roleDisplayOrder1678602320354');
INSERT INTO migrations VALUES (190, 1678694614599, 'sensitiveWords1678694614599');
INSERT INTO migrations VALUES (191, 1678869617549, 'retentionDateKey1678869617549');
INSERT INTO migrations VALUES (192, 1678945242650, 'addPropsForCustomEmoji1678945242650');
INSERT INTO migrations VALUES (193, 1678953978856, 'clipFavorite1678953978856');
INSERT INTO migrations VALUES (194, 1679309757174, 'antennaActive1679309757174');
INSERT INTO migrations VALUES (195, 1679639483253, 'enableChartsForRemoteUser1679639483253');
INSERT INTO migrations VALUES (196, 1679651580149, 'cleanup1679651580149');
INSERT INTO migrations VALUES (197, 1679652081809, 'enableChartsForFederatedInstances1679652081809');
INSERT INTO migrations VALUES (198, 1680228513388, 'channelFavorite1680228513388');
INSERT INTO migrations VALUES (199, 1680238118084, 'channelNotePining1680238118084');
INSERT INTO migrations VALUES (200, 1680491187535, 'cleanup1680491187535');
INSERT INTO migrations VALUES (201, 1680582195041, 'cleanup1680582195041');
INSERT INTO migrations VALUES (202, 1680702787050, 'UserMemo1680702787050');
INSERT INTO migrations VALUES (203, 1680775031481, 'AvatarUrlAndBannerUrl1680775031481');
INSERT INTO migrations VALUES (204, 1680931179228, 'AccountMove1680931179228');
INSERT INTO migrations VALUES (205, 1681400427971, 'ServerRules1681400427971');
INSERT INTO migrations VALUES (206, 1681429921400, 'Event1681429921400');
INSERT INTO migrations VALUES (207, 1681673280586, 'Event1681673280586');
INSERT INTO migrations VALUES (208, 1681675881633, 'Event1681675881633');
INSERT INTO migrations VALUES (209, 1681870960239, 'RoleTLSetting1681870960239');
INSERT INTO migrations VALUES (210, 1682190963894, 'MovedAt1682190963894');
INSERT INTO migrations VALUES (211, 1682754135458, 'PreservedUsernames1682754135458');
INSERT INTO migrations VALUES (212, 1682985520254, 'ChannelColor1682985520254');
INSERT INTO migrations VALUES (213, 1683328299359, 'ChannelArchive1683328299359');
INSERT INTO migrations VALUES (214, 1683682889948, 'PreventAiLarning1683682889948');
INSERT INTO migrations VALUES (215, 1683683083083, 'PublicReactionsDefaultTrue1683683083083');
INSERT INTO migrations VALUES (216, 1683789676867, 'FixTypo1683789676867');
INSERT INTO migrations VALUES (217, 1683847157541, 'UserList1683847157541');
INSERT INTO migrations VALUES (218, 1683869758873, 'UserListFavorites1683869758873');
INSERT INTO migrations VALUES (219, 1684206886988, 'RemoveShowTimelineReplies1684206886988');
INSERT INTO migrations VALUES (220, 1684231006000, 'tweakVarcharLength21684231006000');
INSERT INTO migrations VALUES (221, 1684386446061, 'EmojiImprove1684386446061');
INSERT INTO migrations VALUES (222, 1685378242713, 'MultipleTranslationServices1685378242713');
INSERT INTO migrations VALUES (223, 1685973839966, 'ErrorImageUrl1685973839966');
INSERT INTO migrations VALUES (224, 1686908762393, 'AbuseReportResolver1686908762393');
INSERT INTO migrations VALUES (225, 1688280713783, 'AddMetaOptions1688280713783');
INSERT INTO migrations VALUES (226, 1688720440658, 'RefactorInviteSystem1688720440658');
INSERT INTO migrations VALUES (227, 1688880985544, 'AddIndexToRelations1688880985544');
INSERT INTO migrations VALUES (228, 1689102832143, 'NsfwCache1689102832143');
INSERT INTO migrations VALUES (229, 1689325027964, 'UserBlacklistAnntena1689325027964');
INSERT INTO migrations VALUES (230, 1689580926821, 'ObjectStorageRemoteSetting1689580926821');
INSERT INTO migrations VALUES (231, 1690417561185, 'FixRenoteMuting1690417561185');
INSERT INTO migrations VALUES (232, 1690417561186, 'ChangeCacheRemoteFilesDefault1690417561186');
INSERT INTO migrations VALUES (233, 1690417561187, 'Fix1690417561187');
INSERT INTO migrations VALUES (234, 1690569881926, 'User2faBackupCodes1690569881926');
INSERT INTO migrations VALUES (235, 1690782653311, 'SensitiveChannel1690782653311');
INSERT INTO migrations VALUES (236, 1690796169261, 'PlayVisibility1690796169261');
INSERT INTO migrations VALUES (237, 1691120548582, 'NotificationEmailsForAbuseReport1691120548582');
INSERT INTO migrations VALUES (238, 1691649257651, 'RefineAnnouncement1691649257651');
INSERT INTO migrations VALUES (239, 1691657412740, 'RefineAnnouncement21691657412740');
INSERT INTO migrations VALUES (240, 1691959191872, 'PasskeySupport1691959191872');
INSERT INTO migrations VALUES (241, 1694850832075, 'ServerIconsAndManifest1694850832075');
INSERT INTO migrations VALUES (242, 1694915420864, 'ClippedCount1694915420864');
INSERT INTO migrations VALUES (243, 1695260774117, 'VerifiedLinks1695260774117');
INSERT INTO migrations VALUES (244, 1695288787870, 'FollowingNotify1695288787870');
INSERT INTO migrations VALUES (245, 1695440131671, 'ShortName1695440131671');
INSERT INTO migrations VALUES (246, 1695605508898, 'MutingNotificationTypes1695605508898');
INSERT INTO migrations VALUES (247, 1695901659683, 'NoteUpdatedAt1695901659683');
INSERT INTO migrations VALUES (248, 1695944637565, 'NotificationRecieveConfig1695944637565');
INSERT INTO migrations VALUES (249, 1696003580220, 'AddSomeUrls1696003580220');
INSERT INTO migrations VALUES (250, 1696044626209, 'NoteEditHistory1696044626209');
INSERT INTO migrations VALUES (251, 1696222183852, 'WithReplies1696222183852');
INSERT INTO migrations VALUES (252, 1696318192428, 'NoteUpdateAtHistory1696318192428');
INSERT INTO migrations VALUES (253, 1696323464251, 'UserListMembership1696323464251');
INSERT INTO migrations VALUES (254, 1696331570827, 'Hibernation1696331570827');
INSERT INTO migrations VALUES (255, 1696332072038, 'Clean1696332072038');
INSERT INTO migrations VALUES (256, 1696373953614, 'MetaCacheSettings1696373953614');
INSERT INTO migrations VALUES (257, 1696402675000, 'AddMetaOptions1696402675000');
INSERT INTO migrations VALUES (258, 1696405744672, 'CleanUp1696405744672');
INSERT INTO migrations VALUES (259, 1696417300000, 'AddMetaOptions1696417300000');
INSERT INTO migrations VALUES (260, 1696569742153, 'CleanUp1696569742153');
INSERT INTO migrations VALUES (261, 1696581429196, 'CleanUp1696581429196');
INSERT INTO migrations VALUES (262, 1696604572677, 'PollVotePoll1696604572677');
INSERT INTO migrations VALUES (263, 1696743032098, 'AdsOnStream1696743032098');
INSERT INTO migrations VALUES (264, 1696807733453, 'UserListUserId1696807733453');
INSERT INTO migrations VALUES (265, 1696808725134, 'UserListUserId21696808725134');
INSERT INTO migrations VALUES (266, 1697247230117, 'InstanceSilence1697247230117');
INSERT INTO migrations VALUES (267, 1697420555911, 'DeleteCreatedAt1697420555911');
INSERT INTO migrations VALUES (268, 1697436246389, 'AntennaLocalOnly1697436246389');
INSERT INTO migrations VALUES (269, 1697441463087, 'FollowRequestWithReplies1697441463087');
INSERT INTO migrations VALUES (270, 1697673894459, 'NoteReactionAndUserPairCache1697673894459');
INSERT INTO migrations VALUES (271, 1697737204579, 'DeleteCreatedAt1697737204579');
INSERT INTO migrations VALUES (272, 1697847397844, 'AvatarDecoration1697847397844');
INSERT INTO migrations VALUES (273, 1697941908548, 'AvatarDecoration21697941908548');
INSERT INTO migrations VALUES (274, 1698041201306, 'EnableFtt1698041201306');
INSERT INTO migrations VALUES (275, 1698840138000, 'AddAllowRenoteToExternal1698840138000');
INSERT INTO migrations VALUES (276, 1699141698112, 'AnnouncementSilence1699141698112');
INSERT INTO migrations VALUES (277, 1699432324194, 'RemoteAvaterDecoration1699432324194');
INSERT INTO migrations VALUES (278, 1699437894737, 'ScheduleNote1699437894737');
INSERT INTO migrations VALUES (279, 1700096812223, 'EnableFanoutTimelineDbFallback1700096812223');
INSERT INTO migrations VALUES (280, 1700303245007, 'SupportVerifyMailApi1700303245007');
INSERT INTO migrations VALUES (281, 1700383825690, 'HardMute1700383825690');
INSERT INTO migrations VALUES (282, 1700902349231, 'AddBdayIndex1700902349231');
INSERT INTO migrations VALUES (283, 1701647674000, 'BubbleInstances1701647674000');
INSERT INTO migrations VALUES (284, 1702718871541, 'ffVisibility1702718871541');
INSERT INTO migrations VALUES (285, 1703209889304, 'bannedEmailDomains1703209889304');
INSERT INTO migrations VALUES (286, 1703658526000, 'SupportTrueMailApi1703658526000');
INSERT INTO migrations VALUES (287, 1704185628000, 'NoteUpdatedAt1704185628000');
INSERT INTO migrations VALUES (288, 1704373210054, 'SupportMcaptcha1704373210054');
INSERT INTO migrations VALUES (289, 1704959805077, 'BubbleGameRecord1704959805077');
INSERT INTO migrations VALUES (290, 1705222772858, 'OptimizeNoteIndexForArrayColumns1705222772858');
INSERT INTO migrations VALUES (291, 1705475608437, 'Reversi1705475608437');
INSERT INTO migrations VALUES (292, 1705654039457, 'Reversi21705654039457');
INSERT INTO migrations VALUES (293, 1705793785675, 'Reversi31705793785675');
INSERT INTO migrations VALUES (294, 1705794768153, 'Reversi41705794768153');
INSERT INTO migrations VALUES (295, 1705798904141, 'Reversi51705798904141');
INSERT INTO migrations VALUES (296, 1706081514499, 'Reversi61706081514499');
INSERT INTO migrations VALUES (297, 1706791962000, 'FixMetaDisableRegistration1706791962000');
INSERT INTO migrations VALUES (298, 1707429690000, 'prohibitedWords1707429690000');
INSERT INTO migrations VALUES (299, 1707808106310, 'MakeRepositoryUrlNullable1707808106310');
INSERT INTO migrations VALUES (300, 1708266695091, 'RepositoryUrlFromSyuiloToMisskeyDev1708266695091');
INSERT INTO migrations VALUES (301, 1708399372194, 'PerInstanceModNote1708399372194');
INSERT INTO migrations VALUES (302, 1709126576000, 'OptimizeEmojiIndex1709126576000');
INSERT INTO migrations VALUES (303, 1710512074000, 'UrlPreviewMeta1710512074000');
INSERT INTO migrations VALUES (304, 1710919614510, 'AntennaExcludeBots1710919614510');
INSERT INTO migrations VALUES (305, 1711008460816, 'ExternalWebsiteWarn1711008460816');
INSERT INTO migrations VALUES (306, 1711722198590, 'NoRecursiveDelete1711722198590');
INSERT INTO migrations VALUES (307, 1713656541000, 'AbuseReportNotification1713656541000');
INSERT INTO migrations VALUES (308, 1716129964060, 'ChannelIdDenormalizedForMiPoll1716129964060');
INSERT INTO migrations VALUES (309, 1716197366117, 'MediaSilenceForHosts1716197366117');
INSERT INTO migrations VALUES (310, 1716345015347, 'NotRespondingSince1716345015347');
INSERT INTO migrations VALUES (311, 1716345771510, 'SuspensionStateInsteadOfIsSspended1716345771510');
INSERT INTO migrations VALUES (312, 1716450883149, 'RemoveAntennaNotify1716450883149');
INSERT INTO migrations VALUES (313, 1717117195275, 'InquiryUrl1717117195275');
INSERT INTO migrations VALUES (314, 1720161864577, 'AddDeleteAt1720161864577');
INSERT INTO migrations VALUES (315, 1721666053703, 'FixDriveUrl1721666053703');
INSERT INTO migrations VALUES (316, 1723944246767, 'FollowedMessage1723944246767');
INSERT INTO migrations VALUES (317, 1723982389378, 'AddCustomSplash1723982389378');
INSERT INTO migrations VALUES (318, 1725344700039, 'NoteHistory1725344700039');
INSERT INTO migrations VALUES (319, 1725517326637, 'NoteHistory2_1725517326637');
INSERT INTO migrations VALUES (320, 1726804538569, 'ReactionsBuffering1726804538569');
INSERT INTO migrations VALUES (321, 1727318020265, 'EnableStatsForFederatedInstances1727318020265');
INSERT INTO migrations VALUES (322, 1727491883993, 'UserScore1727491883993');
INSERT INTO migrations VALUES (323, 1727512908322, 'MetaFederation1727512908322');
INSERT INTO migrations VALUES (324, 1728085812127, 'RefineAbuseUserReport1728085812127');
INSERT INTO migrations VALUES (325, 1728550878802, 'Testcaptcha1728550878802');
INSERT INTO migrations VALUES (326, 1728634286056, 'ProhibitedWordsForNameOfUser1728634286056');
INSERT INTO migrations VALUES (327, 1729333924409, 'SigninRequiredForShowContents1729333924409');
INSERT INTO migrations VALUES (328, 1729486255072, 'MakeNotesHiddenBefore1729486255072');
INSERT INTO migrations VALUES (329, 1729518620697, 'RemoteObjectStorage1729518620697');
INSERT INTO migrations VALUES (330, 1730162520000, 'DropObjectStorageRemoteSetting1730162520000');
INSERT INTO migrations VALUES (331, 1730364663000, 'YouBlockedImageUrl1730364663000');
INSERT INTO migrations VALUES (332, 1731385181000, 'checkModeratorInactive1731385181000');
INSERT INTO migrations VALUES (333, 1732593870000, 'checkModeratorInactive21732593870000');
INSERT INTO migrations VALUES (334, 1734793052000, 'LibreTranslate1734793052000');
INSERT INTO migrations VALUES (335, 1736230492103, 'AddAntennaHideNotesInSensitiveChannel1736230492103');
INSERT INTO migrations VALUES (336, 1736686850345, 'CreateNoteDraft1736686850345');
INSERT INTO migrations VALUES (337, 1738098171990, 'customRobotsTxt1738098171990');
INSERT INTO migrations VALUES (338, 1738776889000, 'setFederationAvatarShape1738776889000');
INSERT INTO migrations VALUES (339, 1739006797620, 'GoogleAnalytics1739006797620');
INSERT INTO migrations VALUES (340, 1739785206096, 'AddAvatarRawUrl1739785206096');
INSERT INTO migrations VALUES (341, 1740121393164, 'SystemAccounts1740121393164');
INSERT INTO migrations VALUES (342, 1740129169650, 'SystemAccounts21740129169650');
INSERT INTO migrations VALUES (343, 1740133121105, 'SystemAccounts31740133121105');
INSERT INTO migrations VALUES (344, 1740993126937, 'SystemAccounts41740993126937');
INSERT INTO migrations VALUES (345, 1741279404074, 'SystemAccounts1741279404074');
INSERT INTO migrations VALUES (346, 1741424411879, 'UserFeaturedFixup1741424411879');
INSERT INTO migrations VALUES (347, 1742203321812, 'Chat1742203321812');
INSERT INTO migrations VALUES (348, 1742608337548, 'Chat21742608337548');
INSERT INTO migrations VALUES (349, 1742617546147, 'Chat31742617546147');
INSERT INTO migrations VALUES (350, 1742707840715, 'Chat41742707840715');
INSERT INTO migrations VALUES (351, 1742721896936, 'Chat51742721896936');
INSERT INTO migrations VALUES (352, 1742795111958, 'Chat61742795111958');
INSERT INTO migrations VALUES (353, 1742927188000, 'MigrateMessagingToChat1742927188000');
INSERT INTO migrations VALUES (354, 1743403874305, 'DeliverSuspendedSoftware1743403874305');
INSERT INTO migrations VALUES (355, 1743558299182, 'RoleCopyOnMoveAccount1743558299182');
INSERT INTO migrations VALUES (356, 1744075766000, 'ExcludeNotesInSensitiveChannel1744075766000');
INSERT INTO migrations VALUES (357, 1745378064470, 'CompositeNoteIndex1745378064470');
INSERT INTO migrations VALUES (358, 1746330901644, 'VisibleUserGeneratedContentsForNonLoggedInVisitors1746330901644');
INSERT INTO migrations VALUES (359, 1746361416550, 'UserIpsAddDnsNames1746361416550');
INSERT INTO migrations VALUES (360, 1746422049376, 'SingleUserMode1746422049376');
INSERT INTO migrations VALUES (361, 1746949539915, 'MigrateSomeConfigFileSettingsToMeta1746949539915');
INSERT INTO migrations VALUES (362, 1748310233000, 'AddUrlPreviewAllowRedirect1748310233000');
INSERT INTO migrations VALUES (363, 1750729939704, 'FixAvatarUrl1750729939704');
INSERT INTO migrations VALUES (364, 1751828594933, 'AddDeliveryTargets1751828594933');
INSERT INTO migrations VALUES (365, 1752502434151, 'NoActionOnDraftRelation1752502434151');
INSERT INTO migrations VALUES (366, 1752509043847, 'MigrationCleanup1752509043847');
INSERT INTO migrations VALUES (367, 1753863104203, 'RemoteNotesCleaning1753863104203');
INSERT INTO migrations VALUES (368, 1753868431598, 'RemoveNoteConstraints1753868431598');
INSERT INTO migrations VALUES (369, 1754019326356, 'TweakDefaultFederationSettings1754019326356');
INSERT INTO migrations VALUES (370, 1755168347001, 'PageCountInNote1755168347001');
INSERT INTO migrations VALUES (371, 1755574887486, 'EntrancePageStyle1755574887486');
INSERT INTO migrations VALUES (372, 1756062689648, 'NonCascadingPageEyeCatching1756062689648');
INSERT INTO migrations VALUES (373, 1757823175259, 'SensitiveAd1757823175259');
INSERT INTO migrations VALUES (374, 1758677617888, 'ScheduledPost1758677617888');
INSERT INTO migrations VALUES (375, 1760607435831, 'RoleBadgesRemoteUsers1760607435831');
INSERT INTO migrations VALUES (376, 1760790899857, 'UnnecessaryNullDefault1760790899857');
INSERT INTO migrations VALUES (377, 1760797772000, 'DropScheduleNote1760797772000');
INSERT INTO migrations VALUES (378, 1761287521000, 'AddAutoDeleteNoteSettings1761287521000');
INSERT INTO migrations VALUES (379, 1761569941833, 'AddChannelMuting1761569941833');
INSERT INTO migrations VALUES (380, 1761583921158, 'RemoveNoteEditHistory1761583921158');
INSERT INTO migrations VALUES (381, 1761584610791, 'NoteHistoryAddCwPollEvent1761584610791');
INSERT INTO migrations VALUES (382, 1761595707656, 'chartFederationSoftware1761595707656');
INSERT INTO migrations VALUES (383, 1762351977309, 'AddChatMessageEmojis1762351977309');
INSERT INTO migrations VALUES (384, 1762447519068, 'AddUserCanChat1762447519068');
INSERT INTO migrations VALUES (385, 1762797644990, 'AddInstanceQuarantineLimited1762797644990');
INSERT INTO migrations VALUES (386, 1768893580518, 'ApprovalSignup1768893580518');

SELECT pg_catalog.setval('migrations_id_seq', 386, true);

